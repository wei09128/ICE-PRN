"""Frozen exploratory estrogen-readout test from validated saved losses; no model refits."""
import os
for k in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS'):os.environ.setdefault(k,'2')
from pathlib import Path
from datetime import datetime
import argparse,json,traceback,zipfile
import numpy as np,pandas as pd
import frozen_matching as fm
P=Path(__file__).resolve().parent
SETS=['HALLMARK_ESTROGEN_RESPONSE_EARLY','HALLMARK_ESTROGEN_RESPONSE_LATE']
COV=['MCF7_vehicle_expression','PC3_vehicle_expression','MCF7_repeatability_z','PC3_repeatability_z']

def reduce_losses(L,focal,control):
 # L: orientation, identity, readout, method. Preserve repeated matched controls.
 return np.stack([L[:,:,focal,:].mean(axis=(0,2)),L[:,:,~focal,:].mean(axis=(0,2)),L[:,:,control,:].mean(axis=(0,2))],axis=1)

def contrasts(v):
 if not np.isfinite(v).all() or np.any(v[...,0]<=0):raise ValueError('Invalid loss or comparator denominator; no draws dropped')
 skill=1-v/v[...,0,None]
 return skill[...,0,2,None]-skill[...,1:,2]

def bootstrap(reduced,N=10000):
 n=reduced.shape[1];flat=reduced.transpose(1,0,2,3).reshape(n,-1);rng=np.random.default_rng(2026102305);boot=np.empty((N,2,2))
 for start in range(0,N,250):
  w=rng.multinomial(n,np.full(n,1/n),size=min(250,N-start))/n
  v=(w@flat).reshape(-1,2,3,3);boot[start:start+len(w)]=contrasts(v)
  if start%1000==0:print('Bootstrap',start+len(w),'/',N,flush=True)
 return boot

def plot(out):
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 t=pd.read_csv(out/'primary_endpoints.tsv',sep='\t');fig,axes=plt.subplots(1,2,figsize=(8,3.6),layout='constrained')
 for ax,(name,g) in zip(axes,t.groupby('gene_set',sort=False)):
  x=np.arange(len(g));ax.vlines(x,100*g.lower98_75,100*g.upper98_75,color='#444444');ax.scatter(x,100*g.estimate,color='#cc6677');ax.axhline(0,color='gray',lw=.8);ax.set_xticks(x,['Complement','Matched']);ax.set_title(name.replace('HALLMARK_ESTROGEN_RESPONSE_','').title()+' estrogen response');ax.set_ylabel('Extra learned skill (percentage points)');ax.spines[['top','right']].set_visible(False)
 for ext in ['png','pdf','svg']:fig.savefig(out/('estrogen_readout.'+ext),dpi=200)
 plt.close(fig)

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--cache',type=Path);ap.add_argument('--out',type=Path,default=Path('/mnt/g/ICE-PRN/lincs_paper1/derived')/('estrogen_readout_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')));a=ap.parse_args()
 if a.out.exists():raise FileExistsError('Choose a new output directory')
 a.out.mkdir(parents=True);status=dict(status='RUNNING',exploratory=True,models_refitted=False,new_outcomes_available=False)
 try:
  for n,h in json.loads((P/'INPUT_HASHES.json').read_text()).items():
   if fm.sha(P/n)!=h:raise ValueError('Frozen file changed: '+n)
  masks=pd.read_csv(P/'inputs/FROZEN_LANDMARK_MASKS.tsv',sep='\t',dtype={'pr_gene_id':str});cov=pd.read_csv(P/'inputs/drug_matching_all_readout_covariates.tsv',sep='\t',dtype={'pr_gene_id':str});ids=masks.pr_gene_id.to_numpy()
  if len(ids)!=978 or len(set(ids))!=978 or not np.array_equal(ids,cov.pr_gene_id):raise ValueError('Readout axes differ')
  booleans=[masks[n].to_numpy(bool) for n in SETS]
  if [int(m.sum()) for m in booleans]!=[30,34]:raise ValueError('Frozen mask counts differ')
  provenance=json.loads((P/'inputs/drug_matching_SUMMARY.json').read_text())
  if provenance['status']!='COMPLETE_EXPLORATORY_REVIEW_REQUIRED' or provenance['cache_sha256']!=fm.CACHE_HASH:raise ValueError('Covariate source provenance failed')
  matches=[];diags=[];pairs=[]
  for name,mask in zip(SETS,booleans):
   match,diag=fm.matching(cov[COV].to_numpy(float),mask,ids);matches.append(match);diags.append(dict(gene_set=name,**diag))
   if match is None:raise ValueError('Matching blocked: '+diag['status'])
   f,c,dist,z=match
   for j,(fi,ci) in enumerate(zip(f,c)):pairs.append(dict(gene_set=name,focal_gene_id=ids[fi],focal_symbol=masks.pr_gene_symbol.iloc[fi],control_gene_id=ids[ci],control_symbol=masks.pr_gene_symbol.iloc[ci],distance=dist[j]))
  pd.DataFrame(pairs).to_csv(a.out/'fixed_matched_pairs.tsv',sep='\t',index=False);(a.out/'MATCHING_DIAGNOSTICS.json').write_text(json.dumps(diags,indent=2));status['pairs_sha256']=fm.sha(a.out/'fixed_matched_pairs.tsv')
  # Matching saved before reading model errors.
  cache=a.cache
  if cache is None:
   root=Path('/mnt/c/Wei/ICE-PRN/ICE_PRN_DISEASE_READOUT_v1');valid=[]
   for f in root.glob('results*/identity_gene_losses.npy'):
    try:m=json.loads((f.parent/'SUMMARY.json').read_text())
    except (OSError,ValueError):continue
    if m.get('status')=='COMPLETE_EXPLORATORY_REVIEW_REQUIRED' and m.get('response_sha256')==fm.RESPONSE_HASH:valid.append(f)
   if len(valid)==1:cache=valid[0]
  if cache is None or not cache.is_file():raise FileNotFoundError('Validated gene-loss cache missing/ambiguous. Supply --cache /path/to/identity_gene_losses.npy. No refit performed.')
  meta=json.loads((cache.parent/'SUMMARY.json').read_text());par=pd.read_csv(cache.parent/'parity.tsv',sep='\t')
  if meta.get('response_sha256')!=fm.RESPONSE_HASH or meta.get('parity_checks')!=100 or meta.get('status')!='COMPLETE_EXPLORATORY_REVIEW_REQUIRED' or len(par)!=100 or not par.passed.all() or fm.sha(cache)!=fm.CACHE_HASH:raise ValueError('Original cache provenance/hash/parity failed')
  ref=np.load(P/'inputs/heldout_losses.npz');L=np.load(cache,mmap_mode='r')
  if L.shape!=(2,2,4185,978,3) or L.dtype!=np.dtype('float64'):raise ValueError('Cache axes/type differ')
  checks=[]
  for d in range(2):
   for h in range(2):
    ok=bool(np.allclose(L[d,h].mean(axis=1),ref['group_losses'][d,h][:,[1,2,4]],rtol=1e-8,atol=1e-10));checks.append(dict(direction=fm.DIRS[d],half=h,passed=ok))
    if not ok:raise ValueError('Original global loss parity failed')
  old=pd.read_csv(P/'inputs/original_primary_endpoints.tsv',sep='\t');ann=pd.read_csv(P/'inputs/disease_genes.tsv',sep='\t',dtype=str)
  for d,dis in enumerate(fm.DISEASES):
   mask=np.isin(ids,ann.loc[ann.disease.eq(dis),'gene_id']);a0=L[d][:,:,mask,:].mean(axis=(0,2)).mean(axis=0);b0=L[d][:,:,~mask,:].mean(axis=(0,2)).mean(axis=0);s=1-a0[2]/a0[0];c=1-b0[2]/b0[0]
   for e,v in [('pathway_skill',s),('pathway_minus_complement_skill',s-c)]:
    expected=old.loc[old.direction.eq(fm.DIRS[d])&old.endpoint.eq(e),'estimate'].iloc[0];ok=bool(np.isclose(v,expected,rtol=1e-8,atol=1e-10));checks.append(dict(direction=fm.DIRS[d],endpoint=e,passed=ok))
    if not ok:raise ValueError('Original pathway endpoint parity failed')
  pd.DataFrame(checks).to_csv(a.out/'original_endpoint_checks.tsv',sep='\t',index=False);par.to_csv(a.out/'original_100_parity.tsv',sep='\t',index=False)
  reduced=np.stack([reduce_losses(L[1],mask,m[1]) for mask,m in zip(booleans,matches)])
  point=reduced.mean(axis=1);delta=contrasts(point);B=bootstrap(reduced);rows=[]
  for i,name in enumerate(SETS):
   for j,reference in enumerate(['complement','matched']):
    lo,hi,al,ah=np.quantile(B[:,i,j],[.025,.975,.00625,.99375]);rows.append(dict(direction='PC3_to_MCF7',gene_set=name,n_readouts=int(booleans[i].sum()),reference=reference,estimate=delta[i,j],lower95=lo,upper95=hi,lower98_75=al,upper98_75=ah,pathway_skill=1-point[i,0,2]/point[i,0,0],reference_skill=1-point[i,j+1,2]/point[i,j+1,0],matching_status=diags[i]['status'] if reference=='matched' else 'UNMATCHED'))
  pd.DataFrame(rows).to_csv(a.out/'primary_endpoints.tsv',sep='\t',index=False);np.savez_compressed(a.out/'identity_losses.npz',losses=reduced,identities=ref['group_names'],sets=SETS,readout_groups=['pathway','complement','matched'],methods=['destination_mean','source_copy','learned']);np.savez_compressed(a.out/'bootstrap_primary.npz',contrasts=B);plot(a.out)
  status.update(status='COMPLETE_EXPLORATORY_REVIEW_REQUIRED',new_outcomes_available=True,draws=10000,seed=2026102305,family_size=4,cache_sha256=fm.CACHE_HASH,matching_diagnostics=diags)
 except Exception:status.update(status='FAILED_RETURN_FOR_REVIEW',error=traceback.format_exc());print(status['error'],flush=True)
 finally:
  (a.out/'SUMMARY.json').write_text(json.dumps(status,indent=2));(a.out/'CONTRACT.md').write_bytes((P/'CONTRACT.md').read_bytes())
  with zipfile.ZipFile(a.out/'RETURN_ESTROGEN_READOUT.zip','w',zipfile.ZIP_DEFLATED) as z:
   for f in sorted(a.out.iterdir()):
    if f.is_file() and f.suffix in ['.json','.md','.tsv','.npz','.png','.pdf','.svg']:z.write(f,f.name)
  print('STATUS:',status['status'],'\nRETURN:',a.out/'RETURN_ESTROGEN_READOUT.zip',flush=True)
 if status['status'].startswith('FAILED'):raise SystemExit(1)
if __name__=='__main__':main()
