# Estrogen-response readout test

Extract this folder into `/mnt/c/Wei/ICE-PRN`, then run:

```bash
conda activate ice_prn_cnmf
cd /mnt/c/Wei/ICE-PRN
python ICE_PRN_ESTROGEN_READOUT_TEST_v1/run.py
```

No downloads or model refits. Requires numpy, pandas and matplotlib. It reuses the validated original gene-loss cache on your PC and the covariates from your completed drug matching return. No need to rerun Level-3 extraction. The terminal prints the path to `RETURN_ESTROGEN_READOUT.zip`; return that ZIP even if it reports a failure.

Default cache search: `/mnt/c/Wei/ICE-PRN/ICE_PRN_DISEASE_READOUT_v1/results*/identity_gene_losses.npy`. If there is more than one candidate, supply its exact path using `--cache /path/to/identity_gene_losses.npy`. No fallback model fitting is performed. The output defaults to a new timestamped directory on G:. Override with `--out /path/to/new_directory`.

## Fixed question

Does learned transfer toward MCF7 show greater skill over estrogen-response readouts than over other readouts? Evaluate both fixed external Hallmark sets: early (30 measured landmarks) and late (34). They share 16 measured landmarks. They are not independent replicates and do not exhaust luminal identity.

Four exploratory contrasts: each set versus its complement and versus a reference matched on vehicle expression and technical repeatability in both lines. Both sets and both comparator choices are retained. Use 10,000 shared chemical-identity resamples (seed 2026102305); report ordinary 95% and family-adjusted 98.75% marginal intervals. Fits, splits, masks, matches and covariates are fixed. The intervals do not include their estimation uncertainty or establish biological replication.

Matching uses the exact original rule, without dropping inconvenient focal genes or changing thresholds: absolute mean standardized differences at most 0.1, every distance at most 2, effective control count at least half the focal count. Inadequate matching is reported as a sensitivity result. Pairs are saved before new errors are read.

The plot shows extra learned skill versus complement and matched references. Positive means more improvement within the estrogen-response set; negative means less improvement. A negative contrast can coexist with positive skill within the set. Full skill, reference skill, intervals and balance diagnostics are returned.

The original 100 replay checks, four global-loss checks and four original pathway endpoints must pass. Cache SHA256 must match the validated original. The broad breast-cancer finding remains preserved; a positive estrogen result would not prove that subtype mismatch caused the earlier result. Candidate discovery, treatment ranking and CARNIVAL remain parked. The manuscript and figures have not been changed.

This package is ready to run; real estrogen-subgroup outcomes have not been calculated locally. `python check_runner.py` uses artificial arrays to verify averaging, reused controls, contrast arithmetic, shared resampling and plot generation.

Full official gene lists and archived source pages were delivered separately in `ICE_PRN_ESTROGEN_READOUT_SETS_v1.zip`. The masks in this runner are byte-for-byte copies of that frozen mapping. See CONTRACT.md for provenance and scientific boundaries.
