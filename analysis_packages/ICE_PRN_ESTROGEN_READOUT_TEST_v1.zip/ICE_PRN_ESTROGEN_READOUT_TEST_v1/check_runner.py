"""Small artificial arrays; no real outcome testing."""
import tempfile
from pathlib import Path
import numpy as np,pandas as pd
import run
rng=np.random.default_rng(11);L=rng.uniform(.1,3,(2,7,6,3));mask=np.array([True,True,False,False,False,False]);controls=np.array([3,3]);got=run.reduce_losses(L,mask,controls)
expected=np.empty((7,3,3))
for i in range(7):
 for j,indices in enumerate([np.flatnonzero(mask),np.flatnonzero(~mask),controls]):
  for k in range(3):expected[i,j,k]=np.mean([L[h,i,g,k] for h in range(2) for g in indices])
np.testing.assert_allclose(got,expected)
v=np.array([[[10.,8.,5.],[20.,8.,12.],[5.,8.,4.]]]);np.testing.assert_allclose(run.contrasts(v),[[.1,.3]])
reduced=np.stack([got,got*1.1]);B=run.bootstrap(reduced,N=10);assert B.shape==(10,2,2) and np.isfinite(B).all()
# Same shared draws yield identical contrasts for sets whose losses differ only by scale.
np.testing.assert_allclose(B[:,0],B[:,1],atol=1e-15)
with tempfile.TemporaryDirectory() as tmp:
 rows=[dict(gene_set=s,estimate=.1,lower98_75=-.1,upper98_75=.2) for s in run.SETS for r in range(2)]
 pd.DataFrame(rows).to_csv(Path(tmp)/'primary_endpoints.tsv',sep='\t',index=False);run.plot(Path(tmp))
print('PASS: equal averaging, reused controls, ratio-of-mean contrasts, shared resamples, plot generation')
