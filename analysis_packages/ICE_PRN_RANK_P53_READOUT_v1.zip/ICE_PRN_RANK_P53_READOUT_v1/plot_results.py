"""Plot every frozen rank and direction; intervals are conditional on saved fits."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def plot(out):
 out=Path(out);curves=pd.read_csv(out/'rank_readout_curves.tsv',sep='\t');contrasts=pd.read_csv(out/'primary_contrasts.tsv',sep='\t')
 fig,axes=plt.subplots(2,2,figsize=(10,7),layout='constrained')
 for d,direction in enumerate(('K562_to_RPE1','RPE1_to_K562')):
  ax=axes[0,d]
  for group,color in [('p53','#7b3294'),('complement','#008837')]:
   s=curves[(curves.direction==direction)&(curves.group==group)&(curves['rank']>=0)].sort_values('rank');x=np.arange(len(s))
   ax.errorbar(x,100*s.skill,yerr=100*np.vstack([s.skill-s.lower95,s.upper95-s.skill]),label=group,color=color,marker='o',capsize=2)
  ax.axhline(0,color='gray',lw=.7);ax.set_xticks(range(7),['0','1','2','4','8','16','32']);ax.set_title(direction.replace('_to_',' → '));ax.set_ylabel('Skill against destination mean (%)');ax.legend(frameon=False)
  s=contrasts[contrasts.direction==direction].sort_values('rank');ax=axes[1,d];x=np.arange(len(s))
  ax.vlines(x,100*s.lower99_583333,100*s.upper99_583333,color='#333333');ax.scatter(x,100*s.estimate,color='#333333');ax.axhline(0,color='gray',lw=.8);ax.set_xticks(x,s['rank']);ax.set_ylabel('Extra gain over affine: p53 − complement (pp)');ax.set_xlabel('Correction rank')
 for ax,label in zip(axes.flat,'ABCD'):ax.text(-.13,1.04,label,transform=ax.transAxes,weight='bold');ax.spines[['top','right']].set_visible(False)
 for ext in ('png','pdf','svg'):fig.savefig(out/('rank_p53_readout.'+ext),dpi=200)
 plt.close(fig)
if __name__=='__main__':
 import sys
 plot(sys.argv[1])
