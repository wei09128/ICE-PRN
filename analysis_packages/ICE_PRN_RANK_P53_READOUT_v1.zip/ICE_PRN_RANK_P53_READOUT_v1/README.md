# Rank-by-p53 readout replay

Exploratory follow-up, frozen before calculating the new subgroup outcomes. It asks whether increasing correction rank adds more predictive skill beyond affine within fixed p53 readouts than within complementary readouts. This does not identify a p53 mechanism or network edges.

## Run in WSL

Unzip this folder into `/mnt/c/Wei/ICE-PRN`, then:

```bash
conda activate ice_prn_cnmf
cd /mnt/c/Wei/ICE-PRN
python ICE_PRN_RANK_P53_READOUT_v1/run.py
```

Dependencies: NumPy, pandas, matplotlib. No downloads or refitting choices are requested. The code replays the original frozen model definitions on the original local split responses. If needed, supply `--split-dir /path/to/seed_2026101301` and an unused `--out /path/to/new_result_directory`.

The default source is `/mnt/g/ICE-PRN/transfer_calibration/cell_split_robustness_20261013_160748/seed_2026101301`. Both original split-response files must pass SHA256 validation. This is a substantial replay, rather than plotting saved summary numbers. Runtime depends on CPU, BLAS and disk speed; no fixed estimate has been validated.

## Return

The terminal prints the output path to `RETURN_RANK_P53_READOUT.zip`. Return that ZIP, including when the status reports a failure. Successful output contains every rank and both directions, target losses, bootstrap contrasts, plot and original-result parity checks. A failed parity gate blocks interpretation.

Plot A/B show p53 and complement skill with conditional 95% intervals. Plot C/D show the difference between their gains over affine, with 99.583333% marginal intervals adjusting across the twelve fixed contrasts. A positive contrast means added ranks help p53 readouts more than complementary readouts. An interval spanning zero leaves that contrast unresolved. All estimates condition on fitted models, technical splits and fixed masks; they do not establish independent biological replication.

The Fischer (2017) census table hosted by NCI supplies 343 literal gene symbols. Exact legacy mapping yields 134 measured readouts. The complement contains 7,090 readouts; two ambiguous HSPA14 coordinates are excluded from subgroup comparisons. This readout annotation differs from the external A549 annotation of perturbed targets used in the main p53 coverage analysis.

See CONTRACT.md for the full frozen design. The manuscript and figures have not been changed by this package.

## Local implementation check

```bash
python ICE_PRN_RANK_P53_READOUT_v1/check_runner.py
```

This uses artificial arrays only. It checks masked own-target exclusion, parity with the original evaluator, contrast arithmetic, bootstrap execution and plotting. It is not a biological result.
