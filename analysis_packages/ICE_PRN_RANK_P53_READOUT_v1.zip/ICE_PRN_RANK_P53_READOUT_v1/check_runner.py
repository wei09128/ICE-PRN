"""Small artificial fixtures only; these are not biological results."""
from pathlib import Path
import tempfile
import numpy as np
import pandas as pd
import run

def main():
 rng=np.random.default_rng(7);targets=np.array([f't{i:02}' for i in range(20)]+['t00','t01']);constructs=np.array([f'c{i}' for i in range(22)]);folds=np.array([int(t[1:])%5 for t in targets]);direct=np.arange(22)%10;direct[-1]=-1
 r=rng.normal(size=(2,2,22,10));masks=np.array([np.ones(10,bool),np.arange(10)<3,(np.arange(10)>=3)&(np.arange(10)<9)])
 pred=rng.normal(size=(22,10));truth=rng.normal(size=(22,10));got=run.masked_losses(pred,truth,direct,masks)
 for g,mask in enumerate(masks):
  for i in range(22):
   keep=mask.copy()
   if direct[i]>=0:keep[direct[i]]=False
   assert np.isclose(got[g,i],np.mean((pred[i,keep]-truth[i,keep])**2))
 rows=[]
 def capture(d,h,k,te,ce):
  for j,name in [(1,'destination_mean'),(2,'source_copy'),(3,'diagonal_plus_cross_gene'),(4,'diagonal_affine')]:
   rows.extend(dict(direction=run.DIRS[d],training_half=h,method=name,construct=c,primary_mse=v) for c,v in zip(constructs[te],ce[j]))
 names,old=run.models.evaluate(r,targets,folds,direct,check_anchor=capture)
 with tempfile.TemporaryDirectory() as tmp:
  nn,new=run.replay(r,targets,folds,direct,masks,pd.DataFrame(rows),dict(half_losses=old,constructs_for_replay=constructs),Path(tmp))
  assert np.array_equal(nn,names);np.testing.assert_allclose(new[:,:,:,0],old,rtol=1e-12,atol=1e-12)
  skill=np.zeros((2,len(run.METHODS),3));skill[:,4,1]=.1;skill[:,4,2]=.2;skill[:,5:,1]=.5;skill[:,5:,2]=.3
  np.testing.assert_allclose(run.primary(skill),.3)
  run.summarize(new,names,masks,Path(tmp))
  import plot_results
  plot_results.plot(tmp)
  assert len(pd.read_csv(Path(tmp)/'primary_contrasts.tsv',sep='\t'))==12
 print('PASS: masked own-target exclusion; independent original replay parity; contrast arithmetic; bootstrap and plot smoke checks.')
if __name__=='__main__':main()
