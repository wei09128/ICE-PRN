"""Replay frozen rank fits on fixed external p53 readouts, with protected parity."""
import os
for k in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS'):os.environ.setdefault(k,'4')
from pathlib import Path
from datetime import datetime
import argparse,hashlib,json,re,sys,traceback,zipfile
import numpy as np,pandas as pd
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P/'helpers'))
import models
METHODS=models.METHODS;RANKS=models.RANKS;DIRS=('K562_to_RPE1','RPE1_to_K562');GROUPS=('all','p53','complement')
HASHES={'K562':'5405f345704f4deb5c35ef1af6bb81ea7194cad13c252c06f46538a336b62901','RPE1':'09cdf9b65adcf13f0774f9c6bce6f0cf38ab7ef0273f810c3e2e716265c12d8d'}

def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def masked_losses(pred,truth,direct,masks):
 e=(pred-truth)**2;out=[]
 for mask in masks:
  own=(direct>=0)&mask[np.maximum(direct,0)];count=mask.sum()-own.astype(int)
  if np.any(count<=0):raise ValueError('Empty own-target-excluded readout mask')
  total=e[:,mask].sum(axis=1);rows=np.flatnonzero(own);total[rows]-=e[rows,direct[rows]];out.append(total/count)
 return np.stack(out)
def primary(skill):
 # [...,direction,method,group]; compare added skill beyond affine in p53 vs complement.
 baseline=METHODS.index('rank_0');ix=[METHODS.index('rank_'+str(r)) for r in RANKS[1:]]
 gain=skill[...,ix,:]-skill[...,baseline:baseline+1,:]
 return gain[...,1]-gain[...,2]

def replay(r,targets,folds,direct,masks,reference,old,out):
 names=np.unique(targets);n=len(targets);result=np.full((2,2,len(METHODS),3,len(names)),np.nan);checks=[];rankchecks=[]
 ref=reference.set_index(['direction','training_half','method','construct']).primary_mse
 if not ref.index.is_unique:raise ValueError('Duplicate anchor reference rows')
 constructs=old['constructs_for_replay']
 for phase in ('anchor','grid'):
  for d,(src,dst) in enumerate(((0,1),(1,0))):
   for h in (0,1):
    ce=np.full((len(METHODS),3,n),np.nan)
    for fold in range(5):
     tr=folds!=fold;te=~tr
     if not tr.any() or not te.any():raise ValueError('Empty fold')
     x,y,xe,truth=r[src,h,tr],r[dst,h,tr],r[src,h,te],r[dst,1-h,te]
     print(phase,DIRS[d],'half',h,'fold',fold+1,'/5',flush=True)
     if phase=='anchor':
      model=models.anchor(x,y,targets[tr]);mx,my,b,_,_=model
      preds=[np.zeros_like(truth),np.broadcast_to(my,truth.shape),xe,models.anchor_predict(model,xe),my+(xe-mx)*b]
      for j,p in enumerate(preds):ce[j,:,te]=masked_losses(p,truth,direct[te],masks).T
      for j,name in [(1,'destination_mean'),(2,'source_copy'),(4,'diagonal_affine'),(3,'diagonal_plus_cross_gene')]:
       expected=np.array([ref.loc[(DIRS[d],h,name,c)] for c in constructs[te]])
       actual=ce[j,0,te];ok=bool(np.allclose(actual,expected,rtol=2e-5,atol=2e-8));checks.append(dict(direction=DIRS[d],half=h,fold=fold,method=name,passed=ok,max_abs_error=float(abs(actual-expected).max())))
       pd.DataFrame(checks).to_csv(out/'original_80_anchor_checks.tsv',sep='\t',index=False)
       if not ok:raise ValueError('Original anchor parity failed; no interpretation released')
     else:
      model=models.fit_grid(x,y,targets[tr])
      for rank,p in models.grid_predictions(model,xe):ce[METHODS.index('rank_'+str(rank)),:,te]=masked_losses(p,truth,direct[te],masks).T
    selected=range(5) if phase=='anchor' else range(4,len(METHODS))
    for j in selected:
     if not np.isfinite(ce[j]).all():raise ValueError('Incomplete masked predictions')
     actual_names,agg=models.group_average(ce[j].T,targets)
     if not np.array_equal(actual_names,names):raise ValueError('Target aggregation axis differs')
     result[d,h,j]=agg.T
    # Anchor phase checks only original methods; grid phase completes all 11.
    if phase=='grid':
     for j,name in enumerate(METHODS):
      actual=result[d,h,j,0];expected=old['half_losses'][d,h,j];ok=bool(np.allclose(actual,expected,rtol=2e-5,atol=2e-8));rankchecks.append(dict(direction=DIRS[d],half=h,method=name,passed=ok,max_abs_error=float(abs(actual-expected).max())))
      if not ok:raise ValueError('Saved original rank target-loss vectors did not reproduce')
     pd.DataFrame(rankchecks).to_csv(out/'original_44_rank_checks.tsv',sep='\t',index=False)
 if len(checks)!=80 or len(rankchecks)!=44 or not np.isfinite(result).all():raise ValueError('Incomplete protected replay')
 return names,result

def summarize(half_losses,names,masks,out):
 L=half_losses.mean(axis=1);point=L.mean(axis=-1)
 if np.any(point[:,1,:]<=0):raise ValueError('Nonpositive destination-mean denominator')
 skill=1-point/point[:,1:2,:];estimate=primary(skill);rng=np.random.default_rng(2026102304);N=10000;n=len(names);B=np.empty((N,2,len(METHODS),3))
 flat=L.reshape(-1,n)
 for start in range(0,N,200):
  w=rng.multinomial(n,np.full(n,1/n),size=min(200,N-start))/n;v=(w@flat.T).reshape(-1,2,len(METHODS),3)
  if not np.isfinite(v).all() or np.any(v[:,:,1,:]<=0):raise ValueError('Invalid bootstrap denominator; no draws dropped')
  B[start:start+len(w)]=1-v/v[:,:,1:2,:]
  if start%1000==0:print('Bootstrap',start+len(w),'/',N,flush=True)
 BP=primary(B);rows=[];contrasts=[]
 for d,direction in enumerate(DIRS):
  for j,method in enumerate(METHODS):
   for g,group in enumerate(GROUPS):
    lo,hi=np.quantile(B[:,d,j,g],[.025,.975]);rows.append(dict(direction=direction,method=method,rank=int(method[5:]) if method.startswith('rank_') else -1,group=group,n_readouts=int(masks[g].sum()),mse=point[d,j,g],destination_mean_mse=point[d,1,g],skill=skill[d,j,g],lower95=lo,upper95=hi))
  for j,rank in enumerate(RANKS[1:]):
   lo,hi,al,ah=np.quantile(BP[:,d,j],[.025,.975,.05/24,1-.05/24]);contrasts.append(dict(direction=direction,rank=rank,endpoint='p53_minus_complement_gain_over_affine',estimate=estimate[d,j],lower95=lo,upper95=hi,lower99_583333=al,upper99_583333=ah))
 pd.DataFrame(rows).to_csv(out/'rank_readout_curves.tsv',sep='\t',index=False);pd.DataFrame(contrasts).to_csv(out/'primary_contrasts.tsv',sep='\t',index=False)
 np.savez_compressed(out/'rank_p53_target_losses.npz',half_losses=half_losses,losses=L,targets=names,methods=np.array(METHODS),groups=np.array(GROUPS),ranks=np.array(RANKS),directions=np.array(DIRS))
 np.savez_compressed(out/'bootstrap_primary.npz',p53_minus_complement_gain_over_affine=BP)
 return dict(bootstrap_draws=N,seed=2026102304,primary_family_size=12,readout_counts={g:int(m.sum()) for g,m in zip(GROUPS,masks)})

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--split-dir',type=Path,default=Path('/mnt/g/ICE-PRN/transfer_calibration/cell_split_robustness_20261013_160748/seed_2026101301'));ap.add_argument('--out',type=Path,default=Path('/mnt/g/ICE-PRN/transfer_calibration')/('rank_p53_readouts_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')));a=ap.parse_args()
 if a.out.exists():raise FileExistsError('Choose a new output directory')
 a.out.mkdir(parents=True);status=dict(status='RUNNING',exploratory=True,model_retuned=False,biological_mechanism_established=False,contract_sha256=sha(P/'CONTRACT.md'))
 try:
  for name,h in json.loads((P/'INPUT_HASHES.json').read_text()).items():
   if sha(P/name)!=h:raise ValueError('Frozen input changed: '+name)
  definitions=pd.read_csv(P/'inputs/FROZEN_P53_MASKS.tsv',sep='\t');masks=[definitions[g].to_numpy(bool) for g in GROUPS]
  if [int(m.sum()) for m in masks]!=[7226,134,7090]:raise ValueError('Frozen masks changed')
  (a.out/'FROZEN_P53_MASKS.tsv').write_bytes((P/'inputs/FROZEN_P53_MASKS.tsv').read_bytes());status['mask_sha256']=sha(a.out/'FROZEN_P53_MASKS.tsv')
  arrays=[];axes=[]
  for cell in HASHES:
   path=a.split_dir/(cell+'_split_responses.npz');print('Verify input',cell,flush=True)
   if sha(path)!=HASHES[cell]:raise ValueError('Original response hash mismatch: '+cell)
   with np.load(path,allow_pickle=False) as z:arrays.append(z['responses'].astype(float));axes.append((z['constructs'].astype(str),z['genes'].astype(str)))
  if not all(np.array_equal(a,b) for a,b in zip(axes[0],axes[1])):raise ValueError('Context axes differ')
  constructs,genes=axes[0]
  if not np.array_equal(genes,definitions.gene_id.to_numpy()):raise ValueError('Readout/mask axis differs')
  r=np.stack(arrays);del arrays
  if r.shape!=(2,2,1977,7226) or not np.isfinite(r).all():raise ValueError('Original response shape/values differ')
  targets=np.array([re.search(r'ENSG\d+',c).group() for c in constructs]);folds=np.array([int(hashlib.sha256(('ICE_PRN_TRANSFER_RESPONSE_EXPORT_v1_20261012|'+t).encode()).hexdigest(),16)%5 for t in targets]);gi={g:i for i,g in enumerate(genes)};direct=np.array([gi.get(t,-1) for t in targets])
  oldfile=np.load(P/'inputs/original_rank_target_losses.npz');old={k:oldfile[k] for k in oldfile.files};old['constructs_for_replay']=constructs
  if not np.array_equal(old['methods'],METHODS) or not np.array_equal(old['ranks'],RANKS) or not np.array_equal(old['targets'],np.unique(targets)):raise ValueError('Original rank reference axis differs')
  reference=pd.read_csv(P/'inputs/reference_construct_errors.tsv',sep='\t');reference=reference[reference.evaluation.eq('disjoint_destination')]
  names,losses=replay(r,targets,folds,direct,masks,reference,old,a.out);del r
  status.update(summarize(losses,names,masks,a.out));status.update(status='COMPLETE_EXPLORATORY_REVIEW_REQUIRED',original_anchor_checks=80,original_rank_vector_checks=44,targets=len(names),original_models_sha256=sha(P/'helpers/models.py'))
  import plot_results
  plot_results.plot(a.out)
 except Exception:status.update(status='FAILED_RETURN_FOR_REVIEW',error=traceback.format_exc());print(status['error'],flush=True)
 finally:
  (a.out/'SUMMARY.json').write_text(json.dumps(status,indent=2));(a.out/'CONTRACT.md').write_bytes((P/'CONTRACT.md').read_bytes())
  with zipfile.ZipFile(a.out/'RETURN_RANK_P53_READOUT.zip','w',zipfile.ZIP_DEFLATED) as z:
   for p in sorted(a.out.iterdir()):
    if p.is_file() and p.suffix in ['.json','.md','.tsv','.npz','.png','.pdf','.svg']:z.write(p,p.name)
  print('STATUS:',status['status'],'\nRETURN:',a.out/'RETURN_RANK_P53_READOUT.zip',flush=True)
 if status['status'].startswith('FAILED'):raise SystemExit(1)
if __name__=='__main__':main()
