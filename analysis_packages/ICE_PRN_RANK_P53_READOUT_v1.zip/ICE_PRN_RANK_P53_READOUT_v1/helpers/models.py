"""Training-only weighted predictors shared by simulation and the PC rank job."""
import numpy as np

RANKS=(0,1,2,4,8,16,32)
METHODS=('zero','destination_mean','source_copy','original_rank16')+tuple('rank_'+str(r) for r in RANKS)


def weights(groups):
    _,inv,count=np.unique(groups,return_inverse=True,return_counts=True)
    w=1./count[inv]
    return w/w.sum()


def diagonal(x,y,groups):
    w=weights(groups);mx=w@x;my=w@y;dx=x-mx;dy=y-my
    vx=w@(dx*dx)
    b=np.divide(w@(dx*dy),vx,out=np.zeros_like(vx),where=vx>1e-15)
    return w,mx,my,b


def basis(dx,w,columns):
    omega=np.random.default_rng(2026101401).normal(size=(dx.shape[1],columns))
    wx=dx*np.sqrt(w[:,None])
    q,_=np.linalg.qr(wx@omega,mode='reduced')
    _,_,vt=np.linalg.svd(q.T@wx,full_matrices=False)
    return vt.T


def correction(dx,res,w,v):
    scores=dx@v;gram=scores.T@(w[:,None]*scores)
    penalty=float(np.trace(gram)/len(gram))
    coef=(np.linalg.solve(gram+penalty*np.eye(len(gram)),scores.T@(w[:,None]*res))
          if penalty>1e-15 else np.zeros((v.shape[1],res.shape[1])))
    return coef


def anchor(x,y,groups):
    w,mx,my,b=diagonal(x,y,groups);dx=x-mx
    v=basis(dx,w,24)[:,:min(16,dx.shape[1],len(x))]
    coef=correction(dx,y-my-dx*b,w,v)
    return mx,my,b,v,coef


def anchor_predict(model,x):
    mx,my,b,v,coef=model;dx=x-mx
    return my+dx*b+(dx@v)@coef


def fit_grid(x,y,groups):
    w,mx,my,b=diagonal(x,y,groups);dx=x-mx
    res=y-my-dx*b;v=basis(dx,w,40)
    coefs={r:(v[:,:min(r,v.shape[1])],correction(dx,res,w,v[:,:min(r,v.shape[1])])) for r in RANKS if r}
    return mx,my,b,coefs


def grid_predictions(model,x):
    mx,my,b,coefs=model;dx=x-mx;base=my+dx*b
    yield 0,base
    for r,(v,c) in coefs.items():yield r,base+(dx@v)@c


def mse(pred,truth,direct):
    e=(pred-truth)**2;total=e.sum(axis=1);count=np.full(len(e),e.shape[1],dtype=int)
    valid=direct>=0;rows=np.flatnonzero(valid)
    total[rows]-=e[rows,direct[rows]];count[rows]-=1
    return total/count


def group_average(values,groups):
    names,inv,count=np.unique(groups,return_inverse=True,return_counts=True)
    result=np.zeros((len(names),)+values.shape[1:]);np.add.at(result,inv,values)
    result/=count.reshape((-1,)+(1,)*(values.ndim-1))
    return names,result


def evaluate(r,groups,folds,direct,check_anchor=None,progress=None):
    """Arrays [cell,half,construct,readout]; returns [direction,half,method,target]."""
    n=len(groups);names=np.unique(groups)
    result=np.full((2,2,len(METHODS),len(names)),np.nan)
    # The complete original-anchor pass precedes every rank-grid fit.
    for phase in ('anchor','grid'):
        for di,(src,dst) in enumerate(((0,1),(1,0))):
            for h in (0,1):
                ce=np.full((len(METHODS),n),np.nan)
                for k in range(5):
                    tr=folds!=k;te=~tr
                    if not tr.any() or not te.any():raise ValueError('Empty fold')
                    x,y,xe,truth=r[src,h,tr],r[dst,h,tr],r[src,h,te],r[dst,1-h,te]
                    if phase=='anchor':
                        model=anchor(x,y,groups[tr]);mx,my,b,_,_=model
                        preds=[np.zeros_like(truth),np.broadcast_to(my,truth.shape),xe,anchor_predict(model,xe)]
                        for j,p in enumerate(preds):ce[j,te]=mse(p,truth,direct[te])
                        affine_err=mse(my+(xe-mx)*b,truth,direct[te]);ce[4,te]=affine_err
                        if check_anchor is not None:check_anchor(di,h,k,te,ce[:,te])
                    else:
                        model=fit_grid(x,y,groups[tr])
                        for rank,p in grid_predictions(model,xe):ce[METHODS.index('rank_'+str(rank)),te]=mse(p,truth,direct[te])
                    if progress:progress(phase,di,h,k)
                selected=range(5) if phase=='anchor' else range(4,len(METHODS))
                for j in selected:
                    if not np.isfinite(ce[j]).all():raise ValueError('Incomplete predictions')
                    _,agg=group_average(ce[j],groups);result[di,h,j]=agg
    if not np.isfinite(result).all():raise ValueError('Incomplete rank evaluation')
    return names,result
