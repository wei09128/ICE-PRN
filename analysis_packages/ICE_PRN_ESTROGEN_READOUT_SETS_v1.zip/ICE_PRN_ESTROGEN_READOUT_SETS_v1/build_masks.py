"""Reproduce frozen estrogen readout membership from archived official MSigDB pages."""
from pathlib import Path
import re,html,json,hashlib
import pandas as pd
P=Path(__file__).resolve().parent
land=pd.read_csv(P/'measured_landmarks.tsv',sep='\t',dtype={'pr_gene_id':str})
assert len(land)==978 and land.pr_gene_id.is_unique
masks=land[['pr_gene_id','pr_gene_symbol']].copy();records=[];counts={}
for phase in ['EARLY','LATE']:
 name='HALLMARK_ESTROGEN_RESPONSE_'+phase
 s=(P/'sources'/(name+'.html')).read_bytes().decode('latin1')
 rows=[]
 for tr in re.findall(r'<tr\b[^>]*>(.*?)</tr>',s,re.S):
  cells=re.findall(r'<td\b[^>]*>(.*?)</td>',tr,re.S)
  if len(cells)!=4 or 'view.ncbi.nlm.nih.gov/gene/' not in cells[1]:continue
  clean=lambda t:html.unescape(re.sub('<[^>]+>','',t)).strip()
  rows.append(dict(gene_set=name,source_symbol=clean(cells[0]),entrez_id=clean(cells[1]),current_symbol=clean(cells[2])))
 t=pd.DataFrame(rows);assert len(t)==200 and t.entrez_id.nunique()==200
 t['measured_landmark']=t.entrez_id.isin(land.pr_gene_id)
 t.to_csv(P/(name+'.tsv'),sep='\t',index=False)
 masks[name]=masks.pr_gene_id.isin(t.entrez_id)
 counts[name]=dict(full_genes=len(t),measured_landmarks=int(masks[name].sum()))
 records.extend(rows)
masks.to_csv(P/'FROZEN_LANDMARK_MASKS.tsv',sep='\t',index=False)
a,b=[masks['HALLMARK_ESTROGEN_RESPONSE_'+p] for p in ['EARLY','LATE']]
counts['measured_overlap']=int((a&b).sum());counts['measured_union']=int((a|b).sum())
(P/'COVERAGE.json').write_text(json.dumps(counts,indent=2));print(json.dumps(counts,indent=2))
