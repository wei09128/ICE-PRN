# Fixed estrogen-response readouts

Retrieved 23 October 2026 from the official human MSigDB Hallmark pages:

- HALLMARK_ESTROGEN_RESPONSE_EARLY (M5906): https://www.gsea-msigdb.org/gsea/msigdb/human/geneset/HALLMARK_ESTROGEN_RESPONSE_EARLY.html
- HALLMARK_ESTROGEN_RESPONSE_LATE (M5907): https://www.gsea-msigdb.org/gsea/msigdb/human/geneset/HALLMARK_ESTROGEN_RESPONSE_LATE.html

Both contain 200 genes. Exact Entrez-ID mapping to the benchmark's 978 measured landmarks yields 30 early-response and 34 late-response readouts; 16 overlap (48 unique total). Mapping uses official current Entrez IDs rather than guessed gene aliases. Full tables include source symbols, current symbols and mapping flags. Archived source HTML, landmark coordinates and the reproducible mapping script are included. Rebuild with `python build_masks.py` (pandas required).

These are estrogen-responsive programs, not exhaustive luminal-identity genes, not all direct ER binding targets, and not proof of active estrogen signaling in the benchmark. Their published construction includes separate MCF7 experiments; they are external to our LINCS prediction errors, but not independent of MCF7 as a biological model.

## Follow-up design, not yet executed

Motivation arose after the broad KEGG breast-cancer comparison was known; this is exploratory. Preserve that original result and its imperfect-balance matching sensitivity. Do not replace it based on the new results.

The focused question is whether learned transfer toward MCF7 preferentially predicts estrogen-response readouts compared with other measured readouts. Retain early and late separately, whatever their results; the overlapping lists are not independent biological replication. Do not select their union after inspecting outcomes.

Use the original fixed models, chemical identities, folds, orientations and mean comparator. Primary endpoints are learned skill within each set minus learned skill in its complementary landmarks, PC3-to-MCF7 only. A companion sensitivity should use the original four matching covariates (vehicle expression and technical repeatability in both lines), original matching rule and adequacy diagnostics. With two sets and two comparator choices, report all four planned contrasts and family-adjusted 98.75% marginal intervals as well as ordinary 95% intervals, using 10,000 shared chemical-identity resamples. Fix masks and matches; do not refit models or drop genes to repair balance. Failed balance leaves a sensitivity estimate, not an adjusted biological conclusion.

Positive skill and positive extra skill answer different questions. Neither establishes subtype-specific biology, reversal, efficacy or an explanation for the old negative contrast. A positive follow-up cannot by itself establish that subtype mismatch caused that result. Manuscript and figures are unchanged. No prediction outcomes were examined for the new masks.

Source collection publication: Liberzon et al., The Molecular Signatures Database hallmark gene set collection, Cell Systems (2015), PMID 26771021.
