# RUN-20261023-02 — ribosomal target × p53 readout

User explicitly authorized this follow-up with “go” after the7.28.0 closeout. This supersedes the previous no-new-run instruction for this bounded comparison only. Contract, complete external88-member list and target-group audit were saved before subgroup losses were read. Available mapping had6 missing symbols; excluded without assigning them to the control group. Exact coverage72ribosome/1796nonmember fixed before outcomes.

Only saved losses were reduced; no new model fit, source array extraction or PC run. Original80anchor/44rank checks and12pooled contrasts passed. Primary original rank16 target-group contrasts computed in both directions; secondary full common40-column rank grid retained.10000 stratified shared target-cluster resamples, seed2026102306. Independent primary table arithmetic and interval-bound recomputation passed. Artificial arithmetic/batch-axis/skill fixtures passed. Plot visually inspected.

Results positive for both original-model directional contrasts, forward+9.61points[6.95,12.01], reverse+1.00[.17,1.89], adjusted97.5%. Forward secondary rank effects positive; reverse mixed. No formal direction interaction, mediation, confound-independent claim or new mechanism. The user-reported0.76 remains unverified and was not used.

Current packet is the completed successor record for the proposed ribosomal test in bundle7.28.0. That bundle remains a dated pre-test snapshot; no silent regeneration. Manuscript and combined figure numbering unchanged. All other parked branches and blocked baseline export unchanged.
