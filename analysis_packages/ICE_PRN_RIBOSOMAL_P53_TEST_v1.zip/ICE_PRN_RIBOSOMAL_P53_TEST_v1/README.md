# Completed ribosomal-target × p53-readout follow-up

This test has already run locally from your returned target losses. No PC run is needed. Code, frozen contract, mapping, original input return, all results and figures are included. Reproduce with `python run.py --out /path/to/new_directory` (numpy,pandas,matplotlib). Do not overwrite the completed results directory.

## What was tested

72 exact-symbol KEGG_RIBOSOME targets versus1796 annotated nonmembers;6 unavailable target symbols excluded from both groups. 134 fixed Fischer2017 p53 downstream readouts versus7090 complementary readouts. Nonmembers are not stress-negative controls. The complete official88-member KEGG snapshot is archived, including legacy/mitochondrial annotations; no post-hoc pruning.

Primary: original24-column rank16 cross-gene predictor, compared with affine. Within each target group calculate the gain over affine for p53 readouts minus the corresponding gain for complementary readouts. Compare this preferential gain between ribosome and nonmember targets. Positive means greater preferential p53 improvement for ribosome targets. Losses are averaged before skill ratios; this is not the mean of per-target percentage skills.

## Primary results

| Direction | Ribosome-minus-nonmember preferential gain | Adjusted97.5% interval |
|---|---:|---:|
| K562→RPE1 | +9.61percentage points | +6.95to+12.01 |
| RPE1→K562 | +1.00percentage points | +0.17to+1.89 |

Among ribosome targets, p53 skill rises11.46%→50.18% towardRPE1 and10.30%→27.46% towardK562 (affine→original cross-gene rank16). These are descriptive subgroup point estimates, distinct from the primary difference-of-gains contrast. No0.76 endpoint was reconstructed or used.

The secondary common40-column rank grid retains all12 rank-direction contrasts. Forward estimates are positive at every tested rank after adjustment. Reverse estimates are positive at lower ranks, unresolved at grid16/32; original rank16 and grid16 use different decompositions and must not be conflated. See secondary_rank_contrasts.tsv for all intervals; do not select a favored rank.

## Interpretation and limits

Exploratory target-to-readout association, motivated after known pooled results. It is consistent with shared predictive patterns recovering p53-associated outputs after ribosome perturbation. It does not establish which source genes carry the signal, p53 mediation, RPL5/RPL11–MDM2 mechanism, destination-exclusive pathway activity or biological replication. Do not infer a formal between-direction difference from their separate intervals. Response magnitude, cell recovery and technical repeatability were not matched here. The original p53 target-annotation baseline-expression concern is unchanged.

10000 stratified target-cluster resamples, shared across directions/methods/readouts; conditional on fixed predictions, masks and target groups. Primary two-contrast family uses97.5% marginal intervals; secondary12-contrast family uses99.583333%. Point estimates and all adjusted bounds are in results/. Full losses/skills are included for scale inspection. Original80+44 replay checks and12 pooled contrast reproduction passed before subgroup analysis. Independent table arithmetic and adjusted interval bounds were checked after the run. Plot layout was visually inspected.

The parent7.28.0 bundle is a pre-test snapshot; this completed packet supersedes its “ribosomal test not run” status only. It does not change its blocked RPE1 baseline status or parked workstreams. No manuscript/combined figure edits were made, and no additional analysis is queued automatically.

Source: https://www.gsea-msigdb.org/gsea/msigdb/human/geneset/KEGG_RIBOSOME.html (retrieved23October2026). Archived official source and exact membership table in sources/.
