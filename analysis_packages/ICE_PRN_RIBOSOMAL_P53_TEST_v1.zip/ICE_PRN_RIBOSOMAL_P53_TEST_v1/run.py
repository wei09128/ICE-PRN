"""Bounded exploratory ribosome target by p53 readout test; no model fits."""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ.setdefault(k,'2')
from pathlib import Path
import numpy as np,pandas as pd
import json,hashlib,zipfile,io,argparse
P=Path(__file__).resolve().parent

def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def skill(v):
 # [...,target_group,direction,method,readout] or [target_group,direction,method,readout]
 if not np.isfinite(v).all() or np.any(v[...,1:2,:]<=0):raise ValueError('Invalid loss/mean denominator')
 return 1-v/v[...,1:2,:]
def preferential(s,ix,affine):
 added=s[...,ix,:]-s[...,affine:affine+1,:]
 return added[...,1]-added[...,2]
def difference(s,ix,affine):
 v=preferential(s,ix,affine)
 return v[...,0,:,:]-v[...,1,:,:]
def plot(out):
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 p=pd.read_csv(out/'primary_contrasts.tsv',sep='\t');g=pd.read_csv(out/'secondary_rank_contrasts.tsv',sep='\t')
 fig,axes=plt.subplots(1,2,figsize=(9,3.6),layout='constrained');colors=['#4477aa','#ee7733']
 for d,c in enumerate(colors):
  t=p.iloc[d];axes[0].vlines(d,100*t.lower97_5,100*t.upper97_5,color=c);axes[0].scatter(d,100*t.estimate,color=c)
  t=g[g.direction==p.direction.iloc[d]];x=np.arange(len(t));axes[1].plot(x,100*t.estimate,color=c,marker='o',label=p.direction.iloc[d].replace('_to_',' → '));axes[1].fill_between(x,100*t.lower99_583333,100*t.upper99_583333,color=c,alpha=.15)
 axes[0].set_xticks([0,1],['K562 → RPE1','RPE1 → K562']);axes[0].set_title('Original rank-16 model');axes[1].set_xticks(range(6),['1','2','4','8','16','32']);axes[1].set_xlabel('Common-basis correction rank');axes[1].legend(frameon=False)
 for ax in axes:ax.axhline(0,color='gray',lw=.8);ax.set_ylabel('Ribosome − nonmember\npreferential p53 gain (pp)');ax.spines[['top','right']].set_visible(False)
 for ext in ['png','pdf','svg']:fig.savefig(out/('ribosome_p53.'+ext),dpi=200)
 plt.close(fig)

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--out',type=Path,default=P/'results');args=ap.parse_args();out=args.out
 if out.exists():raise FileExistsError('Choose new --out directory')
 out.mkdir(parents=True)
 for n,h in json.loads((P/'INPUT_HASHES.json').read_text()).items():
  if sha(P/n)!=h:raise ValueError('Frozen file changed: '+n)
 with zipfile.ZipFile(P/'inputs/RETURN_RANK_P53_READOUT.zip') as z:
  meta=json.loads(z.read('SUMMARY.json'));assert meta['status']=='COMPLETE_EXPLORATORY_REVIEW_REQUIRED';assert meta['original_models_sha256']=='b13f5e0b70bc2f4c952477247caeb52c17689451fcbb9ad5d9ae2f621fa4e75b'
  for n,count in [('original_80_anchor_checks.tsv',80),('original_44_rank_checks.tsv',44)]:
   t=pd.read_csv(io.BytesIO(z.read(n)),sep='\t');assert len(t)==count and t.passed.all()
  with np.load(io.BytesIO(z.read('rank_p53_target_losses.npz'))) as a:data={k:a[k] for k in a.files}
  old=pd.read_csv(io.BytesIO(z.read('primary_contrasts.tsv')),sep='\t')
 L=data['half_losses'].mean(axis=1);methods=list(data['methods']);aff=methods.index('rank_0');anchor=methods.index('original_rank16');ranks=[1,2,4,8,16,32];ix=[methods.index('rank_'+str(r)) for r in ranks];dirs=list(data['directions']);readouts=list(data['groups']);assert L.shape==(2,11,3,1874) and readouts==['all','p53','complement'] and dirs==['K562_to_RPE1','RPE1_to_K562']
 pooled=1-L.mean(axis=-1)/L.mean(axis=-1)[:,1:2,:];expected=preferential(pooled,ix,aff);np.testing.assert_allclose(expected.ravel(),old.estimate,atol=1e-14);parity={'original_80_anchor_checks':True,'original_44_rank_checks':True,'all_12_pooled_contrasts':True}
 ann=pd.read_csv(P/'inputs/FROZEN_TARGET_GROUPS.tsv',sep='\t').set_index('target').loc[data['targets']].reset_index();assert len(ann)==1874;gm=[ann.target_group.eq(g).to_numpy() for g in ['ribosome','nonmember']];assert [int(m.sum()) for m in gm]==[72,1796]
 point=np.stack([L[...,m].mean(axis=-1) for m in gm]);s=skill(point);N=10000;rng=np.random.default_rng(2026102306);B=np.empty((N,2,2,11,3))
 for start in range(0,N,200):
  size=min(200,N-start)
  for g,m in enumerate(gm):
   n=int(m.sum());w=rng.multinomial(n,np.full(n,1/n),size=size)/n;v=(w@L[...,m].reshape(-1,n).T).reshape(size,2,11,3);B[start:start+size,g]=skill(v)
  if start%1000==0:print('Bootstrap',start+size,'/',N,flush=True)
 primary=difference(s,[anchor],aff);bp=difference(B,[anchor],aff);secondary=difference(s,ix,aff);bs=difference(B,ix,aff)
 def rows(est,boot,rank_values,quantiles,model):
  result=[]
  for d,direction in enumerate(dirs):
   for j,r in enumerate(rank_values):
    lo,hi,al,ah=np.quantile(boot[:,d,j],[.025,.975,*quantiles]);result.append(dict(direction=direction,model=model,rank=r,estimate=est[d,j],lower95=lo,upper95=hi,adjusted_lower=al,adjusted_upper=ah))
  return pd.DataFrame(result)
 a=rows(primary,bp,[16],[.0125,.9875],'original_rank16').rename(columns={'adjusted_lower':'lower97_5','adjusted_upper':'upper97_5'});b=rows(secondary,bs,ranks,[.05/24,1-.05/24],'common_40_column_grid').rename(columns={'adjusted_lower':'lower99_583333','adjusted_upper':'upper99_583333'});a.to_csv(out/'primary_contrasts.tsv',sep='\t',index=False);b.to_csv(out/'secondary_rank_contrasts.tsv',sep='\t',index=False)
 rows0=[]
 for g,name in enumerate(['ribosome','nonmember']):
  for d,direction in enumerate(dirs):
   for j,method in enumerate(methods):
    for k,readout in enumerate(readouts):rows0.append(dict(target_group=name,n_targets=int(gm[g].sum()),direction=direction,method=method,readouts=readout,mse=point[g,d,j,k],mean_mse=point[g,d,1,k],skill=s[g,d,j,k]))
 pd.DataFrame(rows0).to_csv(out/'all_group_skills.tsv',sep='\t',index=False);ann.to_csv(out/'target_group_audit.tsv',sep='\t',index=False)
 np.savez_compressed(out/'bootstrap_contrasts.npz',primary=bp,secondary=bs);np.savez_compressed(out/'group_skill_bootstrap.npz',skills=B)
 (out/'SUMMARY.json').write_text(json.dumps(dict(status='COMPLETE_EXPLORATORY_REVIEW_REQUIRED',new_models_fitted=False,seed=2026102306,draws=N,group_sizes={'ribosome':72,'nonmember':1796,'unmapped_excluded':6},primary_family=2,secondary_family=12,parity=parity,contract_sha256=sha(P/'CONTRACT.md'),input_return_sha256=sha(P/'inputs/RETURN_RANK_P53_READOUT.zip'),measurement_properties_matched=False),indent=2));(out/'CONTRACT.md').write_bytes((P/'CONTRACT.md').read_bytes());plot(out)
 print(a.to_string(index=False));print('Complete:',out)
if __name__=='__main__':main()
