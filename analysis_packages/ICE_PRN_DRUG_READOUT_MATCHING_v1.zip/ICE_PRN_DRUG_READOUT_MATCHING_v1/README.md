# Matched cancer-pathway readout sensitivity

Question: does the extra predictive skill in fixed cancer-pathway readouts persist when comparison genes have similar baseline expression and technical repeatability? This package is an exploratory follow-up, preserving the original Figure 3D results. It does not rank compounds, refit predictors, change pathways or automatically replace a figure.

## Run in WSL

Extract this folder into /mnt/c/Wei/ICE-PRN, then run:

```bash
conda activate ice_prn_cnmf
cd /mnt/c/Wei/ICE-PRN
python ICE_PRN_DRUG_READOUT_MATCHING_v1/run.py
```

Requirements: numpy, pandas and h5py. These are already used by the existing response pipeline.

The runner looks for:

1. Frozen responses at ICE_PRN_LINCS_DRUG_EXTRACTION_v1/drug_response_export_v1/responses.npz.
2. One existing GSE92742 Level-3 GCTX matrix under /mnt/g/ICE-PRN/lincs_paper1/data/GSE92742.
3. The completed identity_gene_losses.npy cache under ICE_PRN_DISEASE_READOUT_v1/results*/.

If necessary, specify the exact paths with --responses, --level3 and --cache. Multiple matching Level-3 files or caches require an explicit path rather than an arbitrary selection. Example:

```bash
python ICE_PRN_DRUG_READOUT_MATCHING_v1/run.py \
  --level3 /path/to/GSE92742_Broad_LINCS_Level3_INF_mlr12k_n1319138x12328.gctx \
  --cache /path/to/identity_gene_losses.npy
```

No downloads are performed. If Level-3 is missing, the full matched test is blocked and the return contains file availability plus technical-repeatability covariates. Level-4 z-scores cannot substitute for baseline expression. If the validated original gene-loss cache is missing, matching records are retained but inference is blocked; no model is silently refitted.

Results go to a new timestamped directory under /mnt/g/ICE-PRN/lincs_paper1/derived. The final printed return path is RETURN_DRUG_READOUT_MATCHING.zip. Return that small ZIP for review. Keep the large matrices and loss cache on your PC.

## What is fixed

The prostate pathway retains its original 23 measured landmarks toward PC3; the breast pathway retains its original 33 toward MCF7. All 4,185 chemical identities and original model settings, splits and losses remain unchanged. The original unmatched excess skills were +2.87 and +0.07 percentage points. All new matched results will be retained regardless of sign.

### Baseline expression

Official GSE92742 metadata was inspected locally before matching. The fixed manifest has 2,467 DMSO vehicle-control profiles on all 168 MCF7 benchmark plates and 2,308 on all 154 PC3 plates, all at 24 h. The script reads these profiles on the same 978 measured landmark genes from Level-3 normalized expression. It averages profiles within RNA plate, then averages plates equally per cell. These are vehicle-control assay intensities, not raw RNA counts or untreated in-vivo biology. No inferred genes enter the comparison.

### Technical repeatability

For each gene in each cell, average perturbagen IDs within each chemical identity and correlate the two technical halves across identities. Fisher-transform correlations after clipping to [-0.99, 0.99]. Negative values are retained; undefined correlations are missing. This covariate is derived from development-exposed responses. It is not independent biological reliability or a noise ceiling.

### Matching

Each pathway gene is matched to one measured nonmember using standardized Euclidean distance over four fixed covariates: vehicle expression and transformed repeatability in both cell lines. Matching allows control reuse and breaks ties by numeric Entrez ID. The pair list is saved and hashed before reading gene-specific model errors. Matching does not assume nonmembers are disease-unrelated.

All pathway genes must have complete covariates; no focal gene is silently dropped. Report all distances, before/after standardized mean differences, unique controls, reuse and effective reference count. Adequate matching requires distances <=2, absolute SMD <=0.1 on every covariate and effective control count at least half the pathway size. All nearest matches remain if diagnostics fail; results are then an inadequately matched sensitivity, not an association beyond these features. No tuning to repair an unfavorable result.

### Endpoint and uncertainty

Calculate learned skill against the destination training mean separately within pathway and matched reference readouts. Reused control genes receive their matching multiplicity. Average losses before forming skill ratios. Subtract matched-reference skill from pathway skill. The primary family contains two contrasts, one per original direction.

Ten thousand shared chemical-identity draws (seed 2026102303) keep methods, gene sets and directions together. Matches, covariates, models and technical halves remain fixed. Ordinary 95% and approximate Bonferroni-adjusted 97.5% marginal intervals are returned. These do not include covariate/matching estimation or model-refitting uncertainty. No per-gene or per-drug significance tests are performed.

## Validation

All frozen package inputs are hashed. Response and full gene-loss cache hashes must match the previously completed benchmark. All 100 original replay checks, four identity/global-loss anchors and four original pathway/complement endpoints must reproduce before matched inference is released. The analysis does not reinterpret an unavailable or undefined endpoint as zero.

Local fixtures passed for identity-level repeatability, negative correlations, deterministic numeric-ID ties, missing-pathway blocking, ratios of aggregate MSE, Level-3 gene-axis alignment and equal RNA-plate weighting. Optional local check: `python check_runner.py`. Real matching results are pending PC execution; LOCAL_QA.json is not evidence that the real-data test completed.

## Interpretation

If a contrast remains positive with adequate balance, it supports preferential prediction within that fixed annotation after accounting for these measured features. It does not establish cancer-specific mechanisms, mediation, treatment efficacy, phenotype reversal, independent biological replication or a difference between cancers. If it attenuates or becomes uncertain, the prior preferential gain remains sensitive to this comparison; that does not prove baseline expression or repeatability caused the original result. If matching diagnostics fail, the adjusted association remains unresolved.

Candidate discovery, CARNIVAL, treatment ranking and A inference remain parked. The separate K562/RPE1 unfiltered-count recovery job is unchanged.

## Sources

GSE92742 metadata:
https://ftp.ncbi.nlm.nih.gov/geo/series/GSE92nnn/GSE92742/suppl/GSE92742_Broad_LINCS_inst_info.txt.gz
Accessed 23 October 2026. Source SHA-256, deterministic control selection and coverage are retained in METADATA_PREFLIGHT.json and inputs/fixed_vehicle_controls.tsv.

LINCS data-level definitions:
https://clue.io/connectopedia/data_levels
https://clue.io/connectopedia/guide_to_geo_l1000_data
Level 3 contains normalized expression, whereas Level 4 contains standardized response z-scores. Matrix availability and source axes are checked at runtime; a new Level-3 download is not part of this runner.
