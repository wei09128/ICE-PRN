"""Frozen exploratory readout matching; no downloads, model fits or drug ranking."""
import os
for key in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS'):os.environ.setdefault(key,'2')
from pathlib import Path
from datetime import datetime
import argparse,hashlib,json,traceback,zipfile
import numpy as np,pandas as pd
P=Path(__file__).resolve().parent
CELLS=['MCF7','PC3'];DIRS=['MCF7_to_PC3','PC3_to_MCF7'];DISEASES=['prostate_cancer','breast_cancer']
RESPONSE_HASH='24e24107a57a60d487a8960c7e85f5b70c0a04aa8c77bb522736847342420b03'
CACHE_HASH='34211290ef12eee239cc219ac3e255807d95e9ec90ccda15264d2c04ae65138a'

def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def decode(a):return [x.decode() if isinstance(x,bytes) else str(x) for x in a]
def repeatability(r,identities):
 names,inv=np.unique(identities,return_inverse=True);counts=np.bincount(inv);corr=[]
 for c in range(2):
  a=[]
  for half in range(2):
   v=np.zeros((len(names),r.shape[-1]));np.add.at(v,inv,r[c,half]);v/=counts[:,None];v-=v.mean(axis=0);a.append(v)
  den=np.sqrt(np.sum(a[0]**2,axis=0)*np.sum(a[1]**2,axis=0));corr.append(np.divide(np.sum(a[0]*a[1],axis=0),den,out=np.full(r.shape[-1],np.nan),where=den>0))
 return np.stack(corr),names

def extract_baseline(path,genes,out):
 import h5py
 ctl=pd.read_csv(P/'inputs/fixed_vehicle_controls.tsv',sep='\t',dtype=str);plates=sorted(set(zip(ctl.cell_id,ctl.rna_plate)));bi={p:i for i,p in enumerate(plates)};bins=np.array([bi[(r.cell_id,r.rna_plate)] for r in ctl.itertuples()]);sums=np.zeros((len(plates),len(genes)));counts=np.zeros(len(plates),int)
 with h5py.File(path,'r') as h:
  row=decode(h['0/META/ROW/id'][:]);col=decode(h['0/META/COL/id'][:]);m=h['0/DATA/0/matrix']
  if m.shape!=(len(col),len(row)):raise ValueError('Unexpected Level-3 axis orientation')
  rm={v:i for i,v in enumerate(row)};cm={v:i for i,v in enumerate(col)}
  if len(rm)!=len(row) or len(cm)!=len(col):raise ValueError('Duplicate Level-3 axis IDs')
  missing_controls=[x for x in ctl.inst_id if x not in cm];missing_genes=[x for x in genes if x not in rm]
  if missing_controls or missing_genes:raise ValueError(f'Level-3 missing {len(missing_controls)} controls or {len(missing_genes)} landmarks')
  gp=np.array([rm[g] for g in genes]);pos=np.array([cm[x] for x in ctl.inst_id]);order=np.argsort(pos);pos=pos[order];bins=bins[order];j=0
  if len(set(pos))!=len(pos):raise ValueError('Duplicate vehicle profiles')
  while j<len(pos):
   end=j+1
   while end<len(pos) and pos[end]==pos[end-1]+1 and end-j<128:end+=1
   block=np.asarray(m[int(pos[j]):int(pos[end-1])+1,:],float)[:,gp]
   if not np.isfinite(block).all():raise ValueError('Nonfinite Level-3 control expression')
   np.add.at(sums,bins[j:end],block);np.add.at(counts,bins[j:end],1);j=end
   if j%500<128:print('Vehicle profiles',j,'/',len(pos),flush=True)
 if np.any(counts<=0):raise ValueError('A fixed RNA plate has no vehicle expression')
 plate_values=sums/counts[:,None];result=np.stack([plate_values[[c==cell for c,p in plates]].mean(axis=0) for cell in CELLS]);plate_table=pd.DataFrame(dict(cell_id=[c for c,p in plates],rna_plate=[p for c,p in plates],n_vehicle_profiles=counts));plate_table.to_csv(out/'vehicle_plate_counts.tsv',sep='\t',index=False)
 record=dict(path=str(path),bytes=path.stat().st_size,mtime_ns=path.stat().st_mtime_ns,axis_sha256=hashlib.sha256(('\n'.join(row)+'\n---\n'+'\n'.join(col)).encode()).hexdigest(),vehicle_profiles=int(counts.sum()),RNA_plates=len(plates),weighting='mean profiles within plate; equal plate means within each cell',coordinate='Level-3 normalized measured-landmark expression; not counts',selected_baseline_range=[float(result.min()),float(result.max())])
 return result,record

def matching(covariates,mask,ids):
 complete=np.isfinite(covariates).all(axis=1)
 if np.any(mask&~complete):return None,dict(status='BLOCKED_INCOMPLETE_PATHWAY_COVARIATES',missing_pathway_ids=list(ids[mask&~complete]))
 sd=covariates[complete].std(axis=0,ddof=0)
 if np.any(sd<=0):return None,dict(status='BLOCKED_DEGENERATE_COVARIATE')
 z=(covariates-covariates[complete].mean(axis=0))/sd;focal=np.flatnonzero(mask);pool=np.flatnonzero(~mask&complete);pool=pool[np.argsort(ids[pool].astype(int),kind='stable')]
 if not len(pool):return None,dict(status='BLOCKED_EMPTY_REFERENCE_POOL')
 dist=np.sqrt(np.sum((z[focal,None,:]-z[pool][None,:,:])**2,axis=-1));chosen=dist.argmin(axis=1);control=pool[chosen];distance=dist[np.arange(len(focal)),chosen]
 _,counts=np.unique(control,return_counts=True);ess=len(focal)**2/np.sum(counts**2);before=z[focal].mean(axis=0)-z[pool].mean(axis=0);after=z[focal].mean(axis=0)-z[control].mean(axis=0)
 adequate=bool(np.all(distance<=2)&np.all(np.abs(after)<=.1)&(ess>=len(focal)/2))
 return (focal,control,distance,z),dict(status='ADEQUATE_MATCHING' if adequate else 'INADEQUATE_MATCHING_SENSITIVITY_ONLY',n_pairs=len(focal),unique_controls=len(counts),effective_controls=float(ess),max_distance=float(distance.max()),pairs_over_distance_2=int(np.sum(distance>2)),before_SMD=before.tolist(),after_SMD=after.tolist(),adequate=adequate)

def get_skills(v):return 1-v/v[...,0,None]

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--responses',type=Path,default=Path('/mnt/c/Wei/ICE-PRN/ICE_PRN_LINCS_DRUG_EXTRACTION_v1/drug_response_export_v1/responses.npz'));ap.add_argument('--cache',type=Path);ap.add_argument('--level3',type=Path);ap.add_argument('--data-root',type=Path,default=Path('/mnt/g/ICE-PRN/lincs_paper1/data/GSE92742'));ap.add_argument('--out',type=Path,default=Path('/mnt/g/ICE-PRN/lincs_paper1/derived')/('drug_readout_matching_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')));a=ap.parse_args()
 if a.out.exists():raise FileExistsError('Choose a new output directory')
 a.out.mkdir(parents=True);status=dict(status='RUNNING',exploratory=True,models_refitted=False,matching_outcomes_available=False,contract_sha256=sha(P/'CONTRACT.md'))
 try:
  for n,h in json.loads((P/'INPUT_HASHES.json').read_text()).items():
   if sha(P/n)!=h:raise ValueError('Frozen input changed: '+n)
  genes=pd.read_csv(P/'original/measured_landmarks.tsv',sep='\t',dtype=str);ids=genes.pr_gene_id.to_numpy();ann=pd.read_csv(P/'inputs/disease_genes.tsv',sep='\t',dtype=str);masks=[np.isin(ids,ann.loc[ann.disease.eq(d),'gene_id']) for d in DISEASES]
  if [int(m.sum()) for m in masks]!=[23,33]:raise ValueError('Fixed masks changed')
  candidates=sorted(set(p.resolve() for p in a.data_root.rglob('GSE92742*Level3*.gctx'))) if a.data_root.exists() else []
  status['level3_candidates']=[str(p) for p in candidates]
  status['compressed_level3_candidates']=[str(p) for p in a.data_root.rglob('GSE92742*Level3*.gctx.gz')] if a.data_root.exists() else []
  if a.level3 is not None:
   if not a.level3.is_file() or 'Level3' not in a.level3.name:raise ValueError('Explicit Level-3 file unavailable or filename does not identify Level3')
   candidates=[a.level3]
  if not a.responses.is_file():raise FileNotFoundError('Original frozen response arrays missing: '+str(a.responses))
  if sha(a.responses)!=RESPONSE_HASH:raise ValueError('Frozen response hash differs')
  ref=np.load(P/'original/heldout_losses.npz',allow_pickle=False)
  with np.load(a.responses,allow_pickle=False) as z:
   for k in ['pert_ids','identity_groups','folds']:
    if not np.array_equal(z[k],ref[k]):raise ValueError('Response identity/fold axis differs')
   if not np.array_equal(z['gene_ids'].astype(str),ids) or not np.array_equal(z['cells'],CELLS):raise ValueError('Response gene/cell axis differs')
   r=z['responses'].astype(float);identities=z['identity_groups'].astype(str)
  if r.shape!=(2,2,4902,978) or not np.isfinite(r).all():raise ValueError('Frozen response shape/values differ')
  corr,names=repeatability(r,identities);del r
  if len(names)!=4185:raise ValueError('Identity count differs')
  table=genes[['pr_gene_id','pr_gene_symbol']].copy()
  for c,cell in enumerate(CELLS):table[cell+'_half_correlation']=corr[c];table[cell+'_repeatability_z']=np.arctanh(np.clip(corr[c],-.99,.99))
  table.to_csv(a.out/'technical_readout_covariates.tsv',sep='\t',index=False)
  if len(candidates)!=1:
   status['status']='BLOCKED_LEVEL3_MISSING_OR_AMBIGUOUS';status['next_step']='Supply one existing Level-3 normalized expression matrix with --level3. No matched test, abundance proxy, or repeatability-only substitute was run.'
  else:
   baseline,record=extract_baseline(candidates[0],list(ids),a.out);status['vehicle_expression_source']=record
   for c,cell in enumerate(CELLS):table[cell+'_vehicle_expression']=baseline[c]
   covnames=['MCF7_vehicle_expression','PC3_vehicle_expression','MCF7_repeatability_z','PC3_repeatability_z'];cov=table[covnames].to_numpy(float);table.to_csv(a.out/'all_readout_covariates.tsv',sep='\t',index=False)
   pairs=[];diagnostics=[];matches=[];balance=[]
   for d,mask in enumerate(masks):
    match,diag=matching(cov,mask,ids);matches.append(match);diagnostics.append(dict(direction=DIRS[d],**diag))
    if match:
     f,c,dist,z=match
     for j,(fi,ci) in enumerate(zip(f,c)):pairs.append(dict(direction=DIRS[d],pathway_gene_id=ids[fi],pathway_symbol=genes.pr_gene_symbol.iloc[fi],control_gene_id=ids[ci],control_symbol=genes.pr_gene_symbol.iloc[ci],distance=dist[j]))
     for j,n in enumerate(covnames):balance.append(dict(direction=DIRS[d],covariate=n,before_SMD=diag['before_SMD'][j],after_SMD=diag['after_SMD'][j]))
   if pairs:pd.DataFrame(pairs).to_csv(a.out/'fixed_matched_pairs.tsv',sep='\t',index=False)
   if balance:pd.DataFrame(balance).to_csv(a.out/'matching_balance.tsv',sep='\t',index=False)
   (a.out/'MATCHING_DIAGNOSTICS.json').write_text(json.dumps(diagnostics,indent=2));status['matching_diagnostics']=diagnostics
   # Pair list is written and hashed BEFORE reading gene-specific model errors.
   status['fixed_pair_sha256']=sha(a.out/'fixed_matched_pairs.tsv') if pairs else None
   cache=a.cache
   if cache is None:
    root=Path('/mnt/c/Wei/ICE-PRN/ICE_PRN_DISEASE_READOUT_v1');found=sorted(root.glob('results*/identity_gene_losses.npy')) if root.exists() else []
    valid=[]
    for p in found:
     try:q=json.loads((p.parent/'SUMMARY.json').read_text())
     except (OSError,ValueError):continue
     if q.get('status')=='COMPLETE_EXPLORATORY_REVIEW_REQUIRED' and q.get('response_sha256')==RESPONSE_HASH:valid.append(p)
    if len(valid)==1:cache=valid[0]
   if cache is None or not cache.is_file():
    status['status']='BLOCKED_ORIGINAL_GENE_LOSS_CACHE_MISSING_OR_AMBIGUOUS';status['next_step']='Supply the validated original identity_gene_losses.npy with --cache; pairs and diagnostics are already saved. No refit was run.'
   else:
    meta=json.loads((cache.parent/'SUMMARY.json').read_text());par=pd.read_csv(cache.parent/'parity.tsv',sep='\t')
    if meta.get('response_sha256')!=RESPONSE_HASH or meta.get('parity_checks')!=100 or meta.get('status')!='COMPLETE_EXPLORATORY_REVIEW_REQUIRED' or len(par)!=100 or not par.passed.all():raise ValueError('Original cache provenance/parity failed')
    if sha(cache)!=CACHE_HASH:raise ValueError('Original gene-loss cache hash differs')
    L=np.load(cache,mmap_mode='r');expected=(2,2,4185,978,3)
    if L.shape!=expected or L.dtype!=np.dtype('float64') or not np.array_equal(names,ref['group_names'].astype(str)):raise ValueError('Gene-loss cache shape/type/identity axis differs')
    checks=[]
    for d in range(2):
     for h in range(2):
      actual=L[d,h].mean(axis=1);target=ref['group_losses'][d,h][:,[1,2,4]];ok=np.allclose(actual,target,rtol=1e-8,atol=1e-10);checks.append(dict(direction=DIRS[d],half=h,passed=bool(ok)))
      if not ok:raise ValueError('Identity/global loss parity failed')
    pd.DataFrame(checks).to_csv(a.out/'cache_global_checks.tsv',sep='\t',index=False);par.to_csv(a.out/'original_100_parity.tsv',sep='\t',index=False)
    old=pd.read_csv(P/'inputs/original_primary_endpoints.tsv',sep='\t');reduced=np.full((2,4185,2,3),np.nan);oldchecks=[]
    for d,m in enumerate(masks):
     pathway=L[d][:,:,m,:].mean(axis=(0,2));complement=L[d][:,:,~m,:].mean(axis=(0,2));s=get_skills(np.stack([pathway.mean(axis=0),complement.mean(axis=0)]));estimates=[s[0,2],s[0,2]-s[1,2]]
     for e,v in zip(['pathway_skill','pathway_minus_complement_skill'],estimates):
      original=float(old.loc[old.direction.eq(DIRS[d])&old.endpoint.eq(e),'estimate'].iloc[0]);ok=bool(np.isclose(v,original,rtol=1e-8,atol=1e-10));oldchecks.append(dict(direction=DIRS[d],endpoint=e,actual=v,archived=original,passed=ok))
      if not ok:raise ValueError('Original pathway endpoint did not reproduce')
     if matches[d]:
      f,c,dist,z=matches[d];reduced[d,:,0]=pathway;reduced[d,:,1]=L[d][:,:,c,:].mean(axis=(0,2))
    pd.DataFrame(oldchecks).to_csv(a.out/'original_endpoint_checks.tsv',sep='\t',index=False)
    point=get_skills(reduced.mean(axis=1));delta=point[:,0,2]-point[:,1,2];N=10000;boot=np.empty((N,2));rng=np.random.default_rng(2026102303);flat=reduced.transpose(1,0,2,3).reshape(4185,-1)
    for start in range(0,N,250):
     w=rng.multinomial(4185,np.full(4185,1/4185),size=min(250,N-start))/4185;v=(w@flat).reshape(-1,2,2,3);sk=get_skills(v);boot[start:start+len(w)]=sk[:, :,0,2]-sk[:,:,1,2]
     if start%1000==0:print('Bootstrap',start+len(w),'/',N,flush=True)
    rows=[]
    for d in range(2):
     q=np.quantile(boot[:,d],[.025,.975,.0125,.9875]) if np.isfinite(boot[:,d]).all() else [np.nan]*4
     rows.append(dict(direction=DIRS[d],disease=DISEASES[d],n_pathway=int(masks[d].sum()),pathway_skill=point[d,0,2],matched_reference_skill=point[d,1,2],matched_skill_difference=delta[d],lower95=q[0],upper95=q[1],lower97_5=q[2],upper97_5=q[3],matching_status=diagnostics[d]['status']))
    pd.DataFrame(rows).to_csv(a.out/'matched_primary_endpoints.tsv',sep='\t',index=False);np.savez_compressed(a.out/'matched_identity_losses.npz',losses=reduced,identity_groups=names,methods=np.array(['destination_mean','source_copy','learned']));np.savez_compressed(a.out/'bootstrap_primary.npz',matched_skill_difference=boot)
    status.update(status='COMPLETE_EXPLORATORY_REVIEW_REQUIRED',matching_outcomes_available=True,draws=N,seed=2026102303,primary_family=2,cache_sha256=CACHE_HASH)
 except Exception:status.update(status='FAILED_RETURN_FOR_REVIEW',error=traceback.format_exc());print(status['error'],flush=True)
 finally:
  (a.out/'CONTRACT.md').write_bytes((P/'CONTRACT.md').read_bytes());(a.out/'SUMMARY.json').write_text(json.dumps(status,indent=2))
  with zipfile.ZipFile(a.out/'RETURN_DRUG_READOUT_MATCHING.zip','w',zipfile.ZIP_DEFLATED) as z:
   for p in sorted(a.out.iterdir()):
    if p.is_file() and p.suffix in ['.json','.tsv','.md','.npz']:z.write(p,p.name)
  print('STATUS:',status['status'],'\nRETURN:',a.out/'RETURN_DRUG_READOUT_MATCHING.zip',flush=True)
 if status['status'].startswith('FAILED'):raise SystemExit(1)
if __name__=='__main__':main()
