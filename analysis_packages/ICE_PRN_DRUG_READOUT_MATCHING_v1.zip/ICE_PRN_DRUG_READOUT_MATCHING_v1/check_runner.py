"""Independent small checks for matching, identity weighting and vehicle aggregation."""
from pathlib import Path
import importlib.util,tempfile,json
import numpy as np,pandas as pd,h5py
P=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('matched_runner',P/'run.py');r=importlib.util.module_from_spec(s);s.loader.exec_module(r)
# Correlations use identity means, not treating duplicated compound IDs independently.
x=np.array([1.,3.,2.,4.]);y=np.array([4.,0.,8.,3.]);a=np.zeros((2,2,4,2))
for c in range(2):a[c,0,:,0]=x;a[c,1,:,0]=y;a[c,0,:,1]=x;a[c,1,:,1]=-x
corr,names=r.repeatability(a,np.array(['a','a','b','c']));expected=np.corrcoef([2,2,4],[2,8,3])[0,1]
np.testing.assert_allclose(corr[:,0],expected);np.testing.assert_allclose(corr[:,1],-1)
# Numeric Entrez ID, not lexical order, breaks exactly equal distances.
cov=np.array([[0.]*4,[-1.]*4,[1.]*4]);ids=np.array(['99','10','2']);mask=np.array([True,False,False]);match,diag=r.matching(cov,mask,ids);assert match[1].tolist()==[2]
bad=cov.copy();bad[0,0]=np.nan;assert r.matching(bad,mask,ids)[0] is None
# Reused controls retain multiplicity in loss aggregation; do not average skills.
loss=np.array([[10.,8.],[100.,50.]])
assert not np.isclose(1-loss[:,1].mean()/loss[:,0].mean(),(1-loss[:,1]/loss[:,0]).mean())
v=np.array([[[10.,8.],[100.,50.]]]);np.testing.assert_allclose(r.get_skills(v)[0,:,1],[.2,.5])
with tempfile.TemporaryDirectory() as d:
 p=Path(d);(p/'inputs').mkdir();out=p/'out';out.mkdir()
 ctl=pd.DataFrame(dict(inst_id=['A1','A2','B1','C1'],cell_id=['MCF7','MCF7','MCF7','PC3'],rna_plate=['A','A','B','C']));ctl.to_csv(p/'inputs/fixed_vehicle_controls.tsv',sep='\t',index=False)
 data=np.array([[10,20,999],[14,28,999],[100,200,999],[8,16,999]],float)
 with h5py.File(p/'Level3_fixture.gctx','w') as h:
  h.create_dataset('0/META/ROW/id',data=np.array(['1','2','999'],dtype=h5py.string_dtype()));h.create_dataset('0/META/COL/id',data=np.array(['A1','A2','B1','C1'],dtype=h5py.string_dtype()));h.create_dataset('0/DATA/0/matrix',data=data)
 original=r.P;r.P=p
 try:b,record=r.extract_baseline(p/'Level3_fixture.gctx',['2','1'],out)
 finally:r.P=original
 np.testing.assert_allclose(b,[[112,56],[16,8]])
qa=dict(status='PASS',identity_mean_repeatability=True,negative_repeatability_retained=True,numeric_gene_id_tie_break=True,missing_pathway_covariate_blocks=True,skill_uses_aggregate_MSE=True,vehicle_profiles_then_equal_plate_weighting=True,Level3_gene_axis_alignment=True,real_data_execution='PENDING_PC_LEVEL3_AVAILABILITY_AND_EXECUTION')
(P/'LOCAL_QA.json').write_text(json.dumps(qa,indent=2));print(json.dumps(qa))
