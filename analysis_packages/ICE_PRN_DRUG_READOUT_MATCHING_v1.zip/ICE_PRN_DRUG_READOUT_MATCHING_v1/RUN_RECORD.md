# Drug readout matching preparation 23 October 2026

User authorized a sensitivity of Figure 3D's pathway-versus-complement predictive skill to baseline expression and technical repeatability. Original drug results and fit/cache contracts were inspected. Existing Level-4 response arrays encode standardized z-scores, which cannot supply baseline abundance.

Retrieved the official GSE92742 instance metadata and selected DMSO ctl_vehicle profiles at 24 h on the fixed benchmark cell/RNA plates. This provides 2,467 MCF7 profiles across all 168 relevant plates and 2,308 PC3 profiles across all 154 relevant plates. No gene-level model errors were inspected for new matched groups. A contract fixes all four matching covariates, exact masks, nearest matching with replacement, diagnostics, endpoint family and conditional resampling before running the new test.

Prepared a WSL runner that uses an existing Level-3 matrix, frozen response arrays and validated identity-by-gene loss cache. It returns an explicit blocked state if dependencies are unavailable rather than using Level-4 abundance proxies or refitting. Local functional checks passed. The actual matched cancer-pathway results remain unavailable until PC execution and review. No manuscript or figure was replaced.
