# p53 untreated-baseline sensitivity

Read REPORT.md. The baseline-added sensitivity is attenuated and uncertain; imperfect overlap limits its interpretation. It does not establish either p53 specificity or complete explanation by expression.

Reproduce with:

```bash
python scripts/analyze.py
```

Dependencies: numpy, pandas. Inputs are frozen saved target labels, the original matching pairs and returned control-baseline summaries. No new model fits or downloads. Results are in results/. Original pair-for-pair parity and the full input hashes are in results/validation.json. This analysis does not change manuscript/figure files and is not a new complete project checkpoint.
