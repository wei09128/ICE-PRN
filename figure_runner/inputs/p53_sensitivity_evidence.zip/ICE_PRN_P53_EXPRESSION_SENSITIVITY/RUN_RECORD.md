# RUN — 20 October 2026 p53 baseline sensitivity

Execution COMPLETE; evidence EXPLORATORY; manuscript change NOT APPLIED.

Read user-returned 20261020_162736_424719.zip and verified its full manifest. Verified baseline meaning from original split_worker.py/README. Joined native-count baseline summaries for 1,628/1,874 targets. Registered matching variants and diagnostic gates before new calculation. Reproduced the original 461 pairs exactly. Compared original three-covariate matching on full and complete-baseline panels with a five-covariate complete-baseline sensitivity. Added source/destination log1p baselines reduced pooled gap from 10.54 to 6.28 points; conditional 95% interval −0.61 to 15.24. Expanded matches failed fixed overlap/balance gates. Original positive association preserved; expression-independent interpretation unresolved. No trimming, outcome-guided retuning, new predictor fits or Jurkat outcome access. Full provenance and conditional uncertainty limits are in REPORT.md.

Next: incorporate the sensitivity into Results/Discussion if updating the manuscript. Readout-error decomposition still requires original heldout per-readout predictions or exact protected reconstruction inputs; no new fit initiated.
