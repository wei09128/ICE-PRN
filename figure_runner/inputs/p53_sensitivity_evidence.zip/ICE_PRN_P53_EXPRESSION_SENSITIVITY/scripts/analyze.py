from pathlib import Path
import json,hashlib
import numpy as np,pandas as pd
P=Path(__file__).resolve().parents[1];O=P/'results';O.mkdir(exist_ok=True)
plan={'scope':'EXPLORATORY_POST_EXPOSURE_FIXED_LABEL_SENSITIVITY','baseline_coordinate':'native-count control-construct means, averaged over two technical halves; log1p transform for matching; not CPM','variants':['original_3cov_full_panel (parity check)','original_3cov_complete_baselines','expanded_5cov_complete_baselines'],'base_covariates':['ln(max(source_response_RMS,1e-12))','log1p(source_review_cells)','log1p(destination_review_cells)'],'added_covariates':['log1p(source_control_baseline_half_mean)','log1p(destination_control_baseline_half_mean)'],'eligibility':'original copy WORSE_BOTH_HALVES, A549_P53_PROTEIN_HIT or A549_EXPRESSED_BELOW_HIT_CUTOFF; complete-case variants require both native baseline values','matching':'nearest Euclidean standardized covariates within direction, with replacement; pool SD ddof0; target-sorted deterministic tie break','overlap_gate':'report max distance<=2 and absolute standardized mean difference<=0.1 for every covariate within both directions; do not trim or tune','endpoint':'learned BETTER_BOTH_HALVES, original labels unchanged','bootstrap':'10000 fixed matching dependency-component resamples, linked genes across directions/control reuse; percentile95; conditional, no rematching, no model or shared-control resampling','seed':20261021,'original_bootstrap_seed_preserved':20261017,'not_claimed':['p53 causality or specificity','library-size adjusted expression matching','missing target means zero expression','new model fitting','confirmatory inference']}
(P/'ANALYSIS_PLAN.json').write_text(json.dumps(plan,indent=2)+'\n')
x=pd.read_csv(P/'inputs/all_case_rescue.tsv',sep='\t');e=pd.read_csv(P/'inputs/target_control_baselines.tsv',sep='\t')
assert len(x)==3748 and x.target.nunique()==1874 and not x.duplicated(['direction','target']).any();assert len(e)==1874 and e.target.is_unique
assert e.has_readout_baseline.sum()==1628
q=x.merge(e[['target','has_readout_baseline','K562_control_half_mean','RPE1_control_half_mean']],on='target',how='left',validate='many_to_one')
q['source_baseline']=np.where(q.direction.eq('K562_to_RPE1'),q.K562_control_half_mean,q.RPE1_control_half_mean);q['destination_baseline']=np.where(q.direction.eq('K562_to_RPE1'),q.RPE1_control_half_mean,q.K562_control_half_mean)
q['eligible_copyworse_annotation']=q.copy_class.eq('WORSE_BOTH_HALVES')&q.source_status.isin(['A549_P53_PROTEIN_HIT','A549_EXPRESSED_BELOW_HIT_CUTOFF'])
q['baseline_complete']=q.source_baseline.notna()&q.destination_baseline.notna()
q.groupby(['direction','source_status','eligible_copyworse_annotation','baseline_complete']).size().rename('cases').reset_index().to_csv(O/'baseline_availability.tsv',sep='\t',index=False)
q.to_csv(O/'all_cases_with_baselines.tsv',sep='\t',index=False)
base=q[q.eligible_copyworse_annotation].copy();features=plan['base_covariates'];pairs=[];balance=[];stats=[]
for vi,variant in enumerate(plan['variants']):
 name=variant.split(' ')[0];sub=base if vi==0 else base[base.baseline_complete]
 for direction,pool in sub.groupby('direction',sort=True):
  pool=pool.sort_values('target').reset_index(drop=True)
  X=np.column_stack([np.log(np.maximum(pool.source_whole_panel_rms,1e-12)),np.log1p(pool.source_total_review_cells),np.log1p(pool.destination_total_review_cells)])
  names=features.copy()
  if vi==2:X=np.column_stack([X,np.log1p(pool.source_baseline),np.log1p(pool.destination_baseline)]);names+=plan['added_covariates']
  assert np.isfinite(X).all();sd=X.std(axis=0);assert (sd>0).all();Z=(X-X.mean(axis=0))/sd
  h=np.flatnonzero(pool.source_status.eq('A549_P53_PROTEIN_HIT'));c=np.flatnonzero(pool.source_status.eq('A549_EXPRESSED_BELOW_HIT_CUTOFF'));selected=[];distances=[]
  for i in h:
   d=((Z[c]-Z[i])**2).sum(axis=1);j=c[np.argmin(d)];dist=float(np.sqrt(d.min()));selected.append(j);distances.append(dist)
   pairs.append({'variant':name,'direction':direction,'hit_target':pool.iloc[i].target,'control_target':pool.iloc[j].target,'hit_symbol':pool.iloc[i].symbol,'control_symbol':pool.iloc[j].symbol,'distance':dist,'hit_recovered':pool.iloc[i].learned_class=='BETTER_BOTH_HALVES','control_recovered':pool.iloc[j].learned_class=='BETTER_BOTH_HALVES'})
  selected=np.array(selected);rec=pool.learned_class.eq('BETTER_BOTH_HALVES').to_numpy();after=Z[h].mean(0)-Z[selected].mean(0);before=Z[h].mean(0)-Z[c].mean(0)
  for i,f in enumerate(names):balance.append({'variant':name,'direction':direction,'covariate':f,'before_pool_standardized_difference':float(before[i]),'after_pool_standardized_difference':float(after[i])})
  # Also audit omitted expression covariates in restricted 3cov matching.
  if vi==1:
   extra=np.column_stack([np.log1p(pool.source_baseline),np.log1p(pool.destination_baseline)]);zs=(extra-extra.mean(0))/extra.std(0)
   for i,f in enumerate(plan['added_covariates']):balance.append({'variant':name,'direction':direction,'covariate':f,'before_pool_standardized_difference':float(zs[h,i].mean()-zs[c,i].mean()),'after_pool_standardized_difference':float(zs[h,i].mean()-zs[selected,i].mean())})
  stats.append({'variant':name,'direction':direction,'n_hits':len(h),'n_controls':len(c),'n_unique_matched_controls':len(set(selected)),'hit_recoveries':int(rec[h].sum()),'unmatched_control_recoveries':int(rec[c].sum()),'matched_control_recoveries_weighted':int(rec[selected].sum()),'hit_rate':float(rec[h].mean()),'unmatched_control_rate':float(rec[c].mean()),'matched_control_rate':float(rec[selected].mean()),'matched_gap_pp':float(100*(rec[h].mean()-rec[selected].mean())),'max_pair_distance':max(distances),'n_pairs_distance_gt2':int((np.array(distances)>2).sum()),'max_abs_matched_covariate_imbalance':float(abs(after).max()),'matching_gate_pass':bool(max(distances)<=2 and abs(after).max()<=.1)})
pairs=pd.DataFrame(pairs);stats=pd.DataFrame(stats);balance=pd.DataFrame(balance)
full=pairs[pairs.variant.eq('original_3cov_full_panel')];assert len(full)==461 and full.hit_recovered.sum()==314 and full.control_recovered.sum()==266
original=pd.read_csv(P/'inputs/original_matched_pairs.tsv',sep='\t')
a=full[['direction','hit_target','control_target']].sort_values(['direction','hit_target']).reset_index(drop=True);b=original[['direction','hit_target','control_target']].sort_values(['direction','hit_target']).reset_index(drop=True);pd.testing.assert_frame_equal(a,b)
# Preserve graph dependence for every variant independently, no paired-design difference test.
summary=[]
for vi,name in enumerate(stats.variant.drop_duplicates()):
 p=pairs[pairs.variant.eq(name)].copy();parent={t:t for t in set(p.hit_target)|set(p.control_target)}
 def find(t):
  while parent[t]!=t:parent[t]=parent[parent[t]];t=parent[t]
  return t
 def union(a,b):
  a,b=find(a),find(b)
  if a!=b:parent[max(a,b)]=min(a,b)
 for r in p.itertuples():union(r.hit_target,r.control_target)
 p['component']=[find(t) for t in p.hit_target];p['diff']=p.hit_recovered.astype(int)-p.control_recovered.astype(int)
 p.to_csv(O/(name+'_pairs.tsv'),sep='\t',index=False)
 scopes=['pooled']+sorted(p.direction.unique())
 for scope in scopes:
  pp=p if scope=='pooled' else p[p.direction.eq(scope)];g=pp.groupby('component').agg(n=('diff','size'),delta=('diff','sum'));rng=np.random.default_rng(plan['original_bootstrap_seed_preserved'] if vi==0 else plan['seed']+vi)
  draws=[]
  for start in range(0,10000,500):
   w=rng.multinomial(len(g),np.full(len(g),1/len(g)),size=500);draws.append(100*(w@g.delta.to_numpy())/(w@g.n.to_numpy()))
  lo,hi=np.quantile(np.concatenate(draws),[.025,.975]);st=stats[stats.variant.eq(name)]
  if scope!='pooled':st=st[st.direction.eq(scope)]
  summary.append({'variant':name,'direction':scope,'n_pairs':len(pp),'hit_rate':float(pp.hit_recovered.mean()),'matched_control_rate':float(pp.control_recovered.mean()),'gap_pp':float(100*pp['diff'].mean()),'lower95_pp':float(lo),'upper95_pp':float(hi),'n_dependency_components':len(g),'largest_component_pairs':int(g.n.max()),'largest_component_fraction':float(g.n.max()/len(pp)),'all_matching_gates_pass':bool(st.matching_gate_pass.all()),'max_distance':float(st.max_pair_distance.max()),'max_covariate_imbalance':float(st.max_abs_matched_covariate_imbalance.max())})
summary=pd.DataFrame(summary);stats.to_csv(O/'direction_matching_diagnostics.tsv',sep='\t',index=False);balance.to_csv(O/'covariate_balance.tsv',sep='\t',index=False);summary.to_csv(O/'recovery_gap_intervals.tsv',sep='\t',index=False)
validation={'original_matching_reproduced_pair_for_pair':True,'original_hits':314,'original_weighted_controls':266,'original_pairs':461,'baseline_targets':1628,'missing_baseline_targets':246,'no_new_predictor_fits':True,'baseline_source':'hash-verified returned native control arrays','input_sha256':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted((P/'inputs').iterdir()) if f.is_file()}}
(O/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
print(summary.to_string(index=False));print('\nBALANCE\n',balance.to_string(index=False))
