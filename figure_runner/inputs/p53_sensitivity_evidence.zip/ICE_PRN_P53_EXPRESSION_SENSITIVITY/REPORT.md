# Untreated-baseline sensitivity of the p53 recovery association

20 October 2026. Exploratory analysis of fixed saved predictions and labels; no new predictor fits.

## Main finding

The p53-hit recovery advantage is attenuated and becomes uncertain after adding untreated native-count baselines from both lines to nearest-neighbor matching. Expanded matching also fails overlap/balance diagnostics. The result does not establish an expression-independent p53 association, and it does not prove that expression explains the original gap.

| Matching analysis | Hit target-direction cases | Recovery gap (percentage points) | Conditional 95% interval |
|---|---:|---:|---:|
| Original response-size/cell-recovery matching, full panel | 461 | +10.41 | +3.66 to +17.04 |
| Same three covariates, baseline-available subset | 446 | +10.54 | +3.47 to +17.90 |
| Add source and destination baseline values, same subset | 446 | +6.28 | −0.61 to +15.24 |

The first matching reproduced the original saved hit/control pairs exactly, including 314 hit recoveries and 266 weighted control recoveries. Its original bootstrap seed (20261017) was retained. The baseline-available comparison separates a change of cohort from the addition of baseline covariates: restriction alone leaves the point estimate similar, whereas expanded matching gives a smaller estimate. No formal test of the change between estimates was run.

## Baseline provenance and availability

Every file in the returned export passed its manifest SHA256 check. The two original split-response archive hashes match the previously recorded source hashes. Source code shows that control_baselines are native-count means per control construct, then equally averaged across eligible control constructs within each technical half. They are not CPM or library-size-normalized expression values. Responses were computed as log1p(perturbed mean native count) minus log1p(control baseline). Control baseline values are pre-perturbation covariates; response values were not refitted or reconstructed here.

Baselines are available for 1,628/1,874 targets. Missing readout matches for 246 targets remain missing and are not assigned zero expression. Across the two transfer directions, complete-baseline eligibility retains 446/461 copy-worse p53-hit cases and the corresponding available below-cutoff control pool. These target-direction cases are not independent biological replicates.

For matching, the existing three covariates were ln(source-response RMS), log1p(source review-cell count) and log1p(destination review-cell count). Two added covariates were log1p of the average control baseline across halves, separately for source and destination. Covariates were standardized using the eligible pool SD within each transfer direction. Native-count baselines can capture sequencing depth or RNA-content differences in addition to biological expression. This is a baseline-count sensitivity, not a complete adjustment for all expression measurement effects.

## Balance and overlap diagnostics

Original three-covariate matching leaves large expression-baseline imbalances in the complete subset:

| Direction | Source baseline imbalance after original matching | Destination baseline imbalance after original matching |
|---|---:|---:|
| K562→RPE1 | 0.905 | 0.885 |
| RPE1→K562 | 0.892 | 0.917 |

Entries are differences in group means divided by the eligible-pool SD. They show that matching response magnitude and review-cell counts did not balance untreated baseline values.

Expanded matching improves these mean imbalances, but maximum pair distances are 4.257 forward and 2.635 reverse, exceeding the fixed diagnostic limit of 2. The maximum covariate mean imbalance forward is 0.102, slightly above the 0.1 threshold; reverse is 0.069. Both directions therefore fail the full expanded-matching diagnostic gate. The original matching also retained one pair beyond the distance limit, as already documented. No pairs were trimmed and no matching settings were retuned after viewing these outcomes.

The expanded estimate must be described as a nearest-neighbor sensitivity with imperfect overlap, not as a fully adjusted effect. The largest dependency component contains 88/446 matched pairs, further limiting the stability of conditional graph-bootstrap uncertainty.

## Direction-specific expanded sensitivities

- K562→RPE1: +10.53 points (95% interval +1.40 to +20.43), 209 hit cases.
- RPE1→K562: +2.53 points (−6.30 to +13.44), 237 hit cases.

These share genes and are not independent replications. No direction-heterogeneity test was run. The positive forward interval cannot override the pooled uncertainty and failed matching diagnostics.

## Interpretation for the manuscript

The saved three-group annotation counts in Figure 2A and original descriptive/matched recovery results remain unchanged. This new sensitivity weakens an interpretation that the association is independent of untreated baseline expression. It does not remove the observed annotation association or establish that it is entirely a measurement artifact. The conditional program check in Figure 2C still overlaps the whole-response selection and cannot resolve the added confounding question.

Suggested Results addition:

> Among cases with available untreated target baselines, the matched recovery gap was 10.5 percentage points using response magnitude and cell-recovery covariates. Adding native-count baselines from both cell lines reduced the gap to 6.3 points (conditional 95% interval −0.6 to 15.2). Expanded matching did not satisfy all balance and overlap diagnostics, leaving the association beyond baseline expression unresolved.

Suggested Discussion qualification:

> External p53 annotations were associated with learning-based rescue, but this association cannot yet be separated from untreated baseline expression and other correlated features. A baseline-count matching sensitivity attenuated the pooled estimate and yielded an interval spanning zero, with imperfect matching overlap.

Do not update the paper to say that p53-specific mediation, a new p53 regulator or expression-independent context learning has been established. No main figure or manuscript file was modified in this work block. The original result and this sensitivity must both remain visible. No outcome-guided rematching or alternative model search was performed.

## Statistical scope and reproduction

Each matching variant used 10,000 dependency-component bootstrap draws, linking repeated genes across directions and reused controls. Intervals condition on the matches, saved predictions, technical split, annotations and shared controls. They do not include rematching, retraining or biological-replicate uncertainty. No P values or causal effects were estimated.

ANALYSIS_PLAN.json was written before the new matching calculations. This remains retrospective, post-exposure work; the original p53 outcomes had already been inspected. Run `python scripts/analyze.py` with numpy and pandas to reproduce all tables from bundled inputs. Full pair lists, covariate balance, availability counts and source hashes are retained.

Next unresolved task: identify/reproduce saved per-readout heldout predictions before decomposing learned errors by baseline expression. The returned fold-correction parameters are not sufficient by themselves to establish the original base-model predictions. Candidate discovery, CARNIVAL and Jurkat outcomes remain parked.
