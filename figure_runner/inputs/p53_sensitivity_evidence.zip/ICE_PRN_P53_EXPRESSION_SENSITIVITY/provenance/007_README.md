# Three-seed matched-panel sampling repeatability
Seeds 2026101301/02/03. At least 20 total cells in EACH context; same construct
panel and same shared measured genes. The first seed is rerun on this matched
panel, so its centering can differ from the earlier single-context eligible panel.
Other split rules retain v1: balance within construct/GEM group, disjoint cell
halves, disjoint controls, equal control-construct baseline weights, native-count
means, log1p response. Targeted gene excluded from construct scores.

Three passes through each existing HDF5 file. No downloads, model fitting or source
modification. Per-seed response NPZs stay in WSL. Return ZIP contains tables and
summaries. Expect roughly three times the previous cell-split runtime, plus output
compression. Needs approximately 2 GB free output space, depending on compression.

Summaries compare medians within seed, paired context differences per construct,
seed-average differences, and target-level average differences. Seeds reuse cells
and are not independent experimental replicates. Contexts retain different cell
counts and effect strengths; context differences cannot be attributed solely to
noise or biology. No significance threshold, noise ceiling or correction applied.

Syntax and seed/split numerical checks passed locally. Real HDF5 execution is WSL.
