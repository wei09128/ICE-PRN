#!/usr/bin/env python3
import argparse,csv,json,hashlib,re,traceback,zipfile
from pathlib import Path
import h5py
import numpy as np
from metadata_helpers import col,idx,table
SEED=2026101301
MIN_CELLS=20

def assign_halves(labels,batches,barcodes):
 if len(set(barcodes))!=len(barcodes):raise ValueError('Duplicate cell barcodes')
 groups={}
 for i,(c,b) in enumerate(zip(labels,batches)):groups.setdefault((str(c),str(b)),[]).append(i)
 halves=np.zeros(len(labels),dtype=np.int8);balance={}
 for (c,b),inds in sorted(groups.items()):
  inds=sorted(inds,key=lambda i:hashlib.sha256((str(SEED)+'|'+str(barcodes[i])).encode()).digest())
  counts=balance.setdefault(c,[0,0]);first=0 if counts[0]<=counts[1] else 1
  for j,i in enumerate(inds):h=(first+j)%2;halves[i]=h;counts[h]+=1
 return halves

def corr(a,b):
 a=a-a.mean();b=b-b.mean();den=np.linalg.norm(a)*np.linalg.norm(b)
 return float(a@b/den) if den>0 else None

def score(a,b,mask):
 a=a[mask];b=b[mask];dot=float(a@b);den=float(np.linalg.norm(a)*np.linalg.norm(b))
 return {'pearson':corr(a,b),'cosine':dot/den if den>0 else None,'half_difference_mse':float(np.mean((a-b)**2)),'cross_half_dot_per_gene':dot/len(a),'mean_half_squared_amplitude':float((a@a+b@b)/(2*len(a)))}

def main():
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--intake',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
 r={'status':'RUNNING','seed':SEED,'min_total_target_cells':MIN_CELLS,'models_fitted':False,'biological_replication_tested':False,'errors':[],'datasets':[]}
 try:
  bulk={x['official_name']:Path(x['path']) for x in json.loads(a.intake.read_text())['candidates']};info={}
  for context,stem in [('K562','K562_essential'),('RPE1','rpe1')]:
   with h5py.File(a.root/'singlecell_official'/(stem+'_raw_singlecell_01.h5ad'),'r') as f,h5py.File(bulk[stem+'_raw_bulk_01.h5ad'],'r') as b:
    labels=col(f['obs'],'gene_transcript');genes=idx(f['var']);bl=idx(b['obs']);core=np.asarray(b['obs']['core_control'][()],dtype=bool)
    if len(set(genes))!=len(genes):raise ValueError('Duplicate gene IDs')
    corelabs={str(l) for l,c in zip(bl,core) if c};unique,ct=np.unique(labels,return_counts=True);info[context]={'labels':set(labels),'genes':genes,'core':corelabs,'counts':dict(zip(unique,ct))}
  sharedgenes=sorted(set(info['K562']['genes'])&set(info['RPE1']['genes']));targets=sorted((info['K562']['labels']&info['RPE1']['labels'])-(info['K562']['core']|info['RPE1']['core']))
  targets=[t for t in targets if 'non-targeting' not in t and all(info[c]['counts'].get(t,0)>=MIN_CELLS for c in ['K562','RPE1'])];r['shared_readout_genes']=len(sharedgenes);r['shared_target_constructs_before_cell_filter']=len(targets)
  for context,stem in [('K562','K562_essential'),('RPE1','rpe1')]:
   print(context,'READING_METADATA',flush=True)
   with h5py.File(a.root/'singlecell_official'/(stem+'_raw_singlecell_01.h5ad'),'r') as f:
    labels=col(f['obs'],'gene_transcript');batch=col(f['obs'],'gem_group');barcodes=idx(f['obs']);half=assign_halves(labels,batch,barcodes)
    unique,counts=np.unique(labels,return_counts=True);nc=dict(zip(unique,counts));eligible=[t for t in targets if nc.get(t,0)>=MIN_CELLS];controls=sorted(c for c in info[context]['core'] if nc.get(c,0)>=2)
    if len(eligible)<2 or len(controls)<2:raise ValueError('Too few eligible targets/controls')
    selected=eligible+controls;lookup={l:i for i,l in enumerate(selected)};dest=np.array([lookup.get(str(l),-1) for l in labels]);sums=np.zeros((2,len(selected),len(sharedgenes)),dtype=float);n=np.zeros((2,len(selected)),dtype=np.int64)
    gi={str(g):i for i,g in enumerate(info[context]['genes'])};geneix=np.array([gi[g] for g in sharedgenes]);order=np.argsort(geneix);restore=np.argsort(order)
    if not isinstance(f['X'],h5py.Dataset):raise ValueError('Dense X required')
    for start in range(0,len(labels),256):
     stop=min(start+256,len(labels));x=np.asarray(f['X'][start:stop,:],dtype=float)[:,geneix]
     if not np.all(np.isfinite(x)) or np.any(x<0):raise ValueError('Invalid count values')
     keep=dest[start:stop]>=0
     for h in [0,1]:
      mask=keep&(half[start:stop]==h);np.add.at(sums[h],dest[start:stop][mask],x[mask]);np.add.at(n[h],dest[start:stop][mask],1)
     if start%25600==0:print(context,'CELLS',stop,'/',len(labels),flush=True)
    if np.any(n==0) or np.any(np.abs(n[0]-n[1])>1):raise ValueError('Invalid split balance')
    means=sums/n[:,:,None];del sums
    baseline=means[:,len(eligible):,:].mean(axis=1);responses=np.log1p(means[:,:len(eligible),:])-np.log1p(baseline[:,None,:]);del means
    # Descriptive centering removes the response shared by all eligible constructs;
    # it is not a predictive fit or an out-of-fold benchmark.
    centered=responses-responses.mean(axis=1,keepdims=True);rows=[]
    for j,t in enumerate(eligible):
     targetid=re.search(r'ENSG\d+',t);mask=np.ones(len(sharedgenes),dtype=bool)
     if targetid and targetid.group() in gi:
      mask=np.array([g!=targetid.group() for g in sharedgenes])
     raw=score(responses[0,j],responses[1,j],mask);res=score(centered[0,j],centered[1,j],mask)
     rows.append({'construct':t,'target_gene_id':targetid.group() if targetid else '', 'n_half_A':int(n[0,j]),'n_half_B':int(n[1,j]),**{'raw_'+k:v for k,v in raw.items()},**{'centered_'+k:v for k,v in res.items()}})
    table(a.output/(context+'_construct_repeatability.tsv'),rows)
    table(a.output/(context+'_control_split_counts.tsv'),[{'construct':c,'n_half_A':int(n[0,len(eligible)+j]),'n_half_B':int(n[1,len(eligible)+j])} for j,c in enumerate(controls)])
    table(a.output/(context+'_excluded_targets.tsv'),[{'construct':t,'n_cells':int(nc.get(t,0)),'reason':'fewer_than_20_cells'} for t in targets if t not in set(eligible)])
    np.savez_compressed(a.output/(context+'_split_responses.npz'),responses=responses.astype(np.float32),constructs=np.array(eligible),genes=np.array(sharedgenes),half_counts=n[:,:len(eligible)],control_baselines=baseline)
    gene_rows=[]
    for g,gid in enumerate(sharedgenes):gene_rows.append({'gene_id':gid,'across_construct_pearson':corr(responses[0,:,g],responses[1,:,g]),'half_difference_mse':float(np.mean((responses[0,:,g]-responses[1,:,g])**2))})
    table(a.output/(context+'_readout_repeatability.tsv'),gene_rows)
    med={}
    for k in rows[0]:
     if k.startswith(('raw_','centered_')):vals=[x[k] for x in rows if x[k] is not None];med[k]=float(np.median(vals)) if vals else None
    r['datasets'].append({'context':context,'eligible_constructs':len(eligible),'excluded_constructs':len(targets)-len(eligible),'control_constructs':len(controls),'excluded_core_controls':sorted(info[context]['core']-set(controls)),'median_construct_metrics':med,'control_baseline_half_difference_mse':float(np.mean((np.log1p(baseline[0])-np.log1p(baseline[1]))**2))})
    del centered,responses
  r['status']='COMPLETE_SAME_CONSTRUCT_SAMPLING_REPEATABILITY_REVIEW_REQUIRED';r['interpretation']='One deterministic split balanced within construct and GEM group. Disjoint controls; equal control-construct weighting. Technical sampling repeatability only; not biological replication, not a noise ceiling, not a shrinkage/model comparison. Centered scores remove the across-construct common response descriptively. No expression-strength filter.'
 except Exception:r['status']='FAIL_RETURN_FOR_REVIEW';r['errors'].append(traceback.format_exc())
 finally:
  (a.output/'summary.json').write_text(json.dumps(r,indent=2)+'\n')
  with zipfile.ZipFile(a.output/'RETURN_TRANSFER_CELL_SPLIT.zip','w',zipfile.ZIP_DEFLATED) as z:
   for f in sorted(a.output.iterdir()):
    if f.suffix in ('.tsv','.json'):z.write(f,f.name)
  print('RETURN:',a.output/'RETURN_TRANSFER_CELL_SPLIT.zip',flush=True)
 if r['errors']:print(r['errors'][0]);raise SystemExit(1)
if __name__=='__main__':main()
